﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Newtonsoft.Json;
using System.IO;
using System.Threading;

namespace Elephant_Game
{
    class LevelEditor
    {

        const int FLOOR_WIDTH = 21, FLOOR_HEIGHT = 11;
        int[,] floor;
        Rectangle[,] floorBounds;
        Texture2D[] floorAssets;
        Texture2D[] assets;
        List<Rectangle> tileSelect;
        Texture2D[,] enemyAssets;
        List<Rectangle> enemySelect;
        List<Enemy[]> enemies;
        Rectangle currentTileRec;
        Rectangle selectingTile;
        int currentTile;
        bool firstRun;
        Rectangle saveBox, newFloor, up, down;
        Rectangle[] savedFloors;
        bool saveSelect = false, newFloorSelect = false, upSelect = false, downSelect = false;
        int currentFloor;

        List<int[,]> floors = new List<int[,]>();
        List<Rectangle> floorText;
        int topLevel = 0;
        int floorTextSelect = -1;
        int[] selectedTile = new int[2];
        bool mouseDown = false;
        bool newFloorCheck = false;
        bool selectingEnemy = false, canPlaceEnemy = false;
        int enemySelectIndex = -1, selectingEnemyIndex = -1;
        Rectangle placementRec;
        Collisions collisions = new Collisions();
        Rectangle removeRec;
        bool removingEnemy = false, removeSelect;

        int[,] defaultFloor = {
                         {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                         {0, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 0},
                         {0, 17, 4, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 4, 17, 0},
                         {0, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 0},
                         {0, 17, 17, 17, 17, 17, 17, 17, 17, 17, 4, 17, 17, 17, 17, 17, 17, 17, 17, 17, 0},
                         {0, 17, 17, 17, 17, 17, 17, 17, 17, 4, 4, 4, 17, 17, 17, 17, 17, 17, 17, 17, 0},
                         {0, 17, 17, 17, 17, 17, 17, 17, 17, 17, 4, 17, 17, 17, 17, 17, 17, 17, 17, 17, 0},
                         {0, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 0},
                         {0, 17, 4, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 4, 17, 0},
                         {0, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 0},
                         {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
                    };

        bool textException = false;

        public void setUp(int[,] floorGet, Rectangle[,] floorBoundsGet, Texture2D[] assets, Texture2D[] editorAssets, Texture2D[,] enemyTextures, GraphicsDevice graphics)
        {
            enemies = new List<Enemy[]>();
            currentFloor = 0;
            topLevel = 0;
            floor = new int[FLOOR_HEIGHT, FLOOR_WIDTH];
            floorBounds = new Rectangle[FLOOR_HEIGHT, FLOOR_WIDTH];
            currentTile = 0;
            firstRun = true;

            floor = floorGet;
            floorBounds = floorBoundsGet;
            floorAssets = assets;
            this.assets = editorAssets;
            this.enemyAssets = enemyTextures;

            int size = 50;
            

            tileSelect = new List<Rectangle>();
            int loopNum = 0;
            for (int i = 0; i < floorAssets.Length; i++)
            {
                if (i == 19 || i == 20)
                {
                    //do nothing
                }
                else
                {
                    tileSelect.Add(new Rectangle((loopNum % 3) * size, (loopNum / 3) * size, size, size));
                    loopNum++;
                }
            }
            currentTile = 0;

            int count = 0;
            enemySelect = new List<Rectangle>();
            for (int i = 0; i < enemyAssets.Length/3; i++)
            {
                if (i == 2 || i == 4 || i == 5 || i == 6 || i == 7 || i == 8)
                {
                    //do nothing
                }
                else
                {
                    enemySelect.Add(new Rectangle((int)(((graphics.Viewport.Width / 3) * 2) + (count * (enemyAssets[0,0].Width * 1.5))), graphics.Viewport.Height / 20, enemyAssets[i,0].Width, enemyAssets[i,0].Height));
                    count++;
                }
            }

            floors = new List<int[,]>();

            LoadFiles();
            
            if (enemies == null)
            {
                enemies = new List<Enemy[]>();
            }

            saveBox = new Rectangle((graphics.Viewport.Width / 2)-100, graphics.Viewport.Height - 100, 200, 50);
            newFloor = new Rectangle(graphics.Viewport.Width/24, graphics.Viewport.Height - 100, 200, 50);

            up = new Rectangle(graphics.Viewport.Width / 24 + 30, graphics.Viewport.Height / 6 - 75, 100, 50);
            down = new Rectangle(graphics.Viewport.Width / 24, graphics.Viewport.Height / 6 + 525, 125, 50);

            updateLevelText(graphics);

            removeRec = new Rectangle(graphics.Viewport.Width - 75, 25, 50, 50);

        }

        private void updateLevelText(GraphicsDevice graphics)
        {
            floorText = new List<Rectangle>();
            try
            {
                for (int i = 0; i < floors.Count; i++)
                {
                    Rectangle rec = new Rectangle(graphics.Viewport.Width / 24, (graphics.Viewport.Height / 6) + (50 * i) - (topLevel * 50), 150, 50);
                    floorText.Add(rec);
                }
            } catch(Exception ex)
            {
                if (!textException)
                {
                    Console.WriteLine("Unable to create level text, empty file?\nException: " + ex);
                    Console.WriteLine("Attempting to fix...");
                    floors = new List<int[,]>();
                    floors.Add(defaultFloor);
                    SaveFile(graphics);
                    LoadFiles();
                    updateLevelText(graphics);
                    Console.WriteLine("Done");
                    textException = true;
                }
            }
        }
        
        private void checkSaveSelect(MouseState mouse, GraphicsDevice graphics)
        {
            Rectangle mouseRec = new Rectangle(mouse.X, mouse.Y, 1, 1);
            if (mouseRec.Intersects(saveBox))
            {
                saveSelect = true;
                if (mouse.LeftButton == ButtonState.Pressed && !mouseDown)
                {
                    floors[currentFloor] = floor;
                    SaveFile(graphics);
                    LoadFiles();
                }
            }
            else
            {
                saveSelect = false;
            }
        }

        private void checkNewFloorSelect(MouseState mouse, GraphicsDevice graphics)
        {
            Rectangle mouseRec = new Rectangle(mouse.X, mouse.Y, 1, 1);
            if (mouseRec.Intersects(newFloor))
            {
                newFloorSelect = true;
                if (mouse.LeftButton == ButtonState.Pressed && !mouseDown)
                {
                    floors.Add(defaultFloor);
                    currentFloor = floors.Count - 1;
                    floor = floors[currentFloor];

                    topLevel = currentFloor - 9;
                    if (topLevel <= 0)
                    {
                        topLevel = 0;
                    }
                    SaveFile(graphics);
                    LoadFiles();

                    floorTextSelect = currentFloor;

                    updateLevelText(graphics);
                    newFloorCheck = true;
                    enemies.Add(new Enemy[0]);
                }
            }
            else
            {
                newFloorSelect = false;
            }
        }

        private void checkFloorSelect (MouseState mouse, GraphicsDevice graphics)
        {
            Rectangle mouseRec = new Rectangle(mouse.X, mouse.Y, 1, 1);

            floorTextSelect = -1;
            for (int i = 0; i < floorText.Count; i++)
            {
                if (mouseRec.Intersects(floorText[i]))
                {
                    floorTextSelect = i;
                    if (mouse.LeftButton == ButtonState.Pressed && !mouseDown && (i >= topLevel && i <= topLevel + 9))
                    {
                        floors[currentFloor] = floor;
                        SaveFile(graphics);
                        LoadFiles();

                        floor = floors[floorTextSelect];
                        currentFloor = i;
                        selectingEnemy = false;
                        selectingEnemyIndex = -1;
                        enemySelectIndex = -1;
                    }
                }
            }
        }

        private void checkUpSelect(MouseState mouse, GraphicsDevice graphics)
        {
            Rectangle mouseRec = new Rectangle(mouse.X, mouse.Y, 1, 1);
            if (mouseRec.Intersects(up))
            {
                upSelect = true;
                if (mouse.LeftButton == ButtonState.Pressed && !mouseDown)
                {
                   
                    
                    if (topLevel == 0)
                    {
                        //movement
                    }
                    else
                    {
                        topLevel--;
                        if (currentFloor == topLevel + 10)
                        {
                            currentFloor--;
                        }
                        floor = floors[currentFloor];
                        updateLevelText(graphics);
                    }
                }
            }
            else
            {
                upSelect = false;
            }
        }

        private void checkDownSelect(MouseState mouse, GraphicsDevice graphics)
        {
            Rectangle mouseRec = new Rectangle(mouse.X, mouse.Y, 1, 1);
            if (mouseRec.Intersects(down))
            {
                downSelect = true;
                if (mouse.LeftButton == ButtonState.Pressed && !mouseDown)
                {
                    if (topLevel + 10 >= floorText.Count)
                    {
                        //stop movement
                    }
                    else
                    {
                        topLevel++;
                        if (currentFloor == topLevel-1)
                        {
                            currentFloor++;
                        }
                        floor = floors[currentFloor];
                        updateLevelText(graphics);
                    }
                }
            }
            else
            {
                downSelect = false;
            }
        }

        public void checkEnemySelct(MouseState mouse, GraphicsDevice graphics)
        {
            Rectangle mouseRec = new Rectangle(mouse.X, mouse.Y, 1, 1);
            bool foundOne = false;
            for (int i = 0; i < enemySelect.Count; i++)
            {
                if (mouseRec.Intersects(enemySelect[i]))
                {
                    selectingEnemyIndex = i;
                    foundOne = true;
                    if (mouse.LeftButton == ButtonState.Pressed && !mouseDown)
                    {
                        removingEnemy = false;
                        if (selectingEnemyIndex >= 2)
                        {
                            enemySelectIndex = i + 1;
                        }
                        else
                        {
                            enemySelectIndex = i;
                        }
                        selectingEnemy = true;
                        currentTile = -1;
                        currentTileRec = new Rectangle(0,0,0,0);
                    }
                }
            }

            if (!foundOne)
            {
                selectingEnemyIndex = -1;
            }
        }

        public void CheckEnemyPlacement(MouseState mouse, GraphicsDevice graphics)
        {
            if (placementRec == null)
            {
                return;
            }
            Rectangle mouseRec = new Rectangle(mouse.X, mouse.Y, 1, 1);
            Rectangle charRec = new Rectangle(mouse.X - (enemyAssets[enemySelectIndex, 0].Width / 2), mouse.Y - (enemyAssets[enemySelectIndex, 0].Height / 2), enemyAssets[enemySelectIndex, 0].Width, enemyAssets[enemySelectIndex, 0].Height);
            canPlaceEnemy = true;
            if (charRec.Intersects(placementRec))
            {
                foreach (var item in enemies[currentFloor])
                {
                    if (charRec.Intersects(item.HitBox))
                    {
                        canPlaceEnemy = false;
                    }
                }

                int tileX = 0, tileY = 0;
                for (int i = 1; i < FLOOR_HEIGHT - 1; i++)
                {
                    for (int l = 1; l < FLOOR_WIDTH - 1; l++)
                    {
                        if (floorBounds[i, l].Intersects(mouseRec))
                        {
                            tileX = i;
                            tileY = l;
                        }
                    }
                }
                
                if (collisions.checkMove(floor[tileX, tileY]))
                {
                    canPlaceEnemy = false;
                }
            }
            else
            {
                canPlaceEnemy = false;
            }

            if (canPlaceEnemy && mouse.LeftButton == ButtonState.Pressed && !mouseDown)
            {
                Enemy enemyAdd = null;
                switch (enemySelectIndex)
                {
                    case 0:
                        enemyAdd = new Enemy(mouse.X - (enemyAssets[enemySelectIndex, 0].Width / 2), mouse.Y - (enemyAssets[enemySelectIndex, 0].Height / 2), enemyAssets[0, 0]);
                        enemyAdd.EnemyType = 0;
                        enemyAdd.Health = 10;
                        enemyAdd.Speed = 5;
                        enemyAdd.Damage = 1;
                        break;
                    case 1:
                        enemyAdd = new Enemy(mouse.X - (enemyAssets[enemySelectIndex, 0].Width / 2), mouse.Y - (enemyAssets[enemySelectIndex, 0].Height / 2), enemyAssets[1, 0]);
                        enemyAdd.EnemyType = 1;
                        enemyAdd.Health = 15;
                        enemyAdd.Speed = 2;
                        enemyAdd.Damage = 1;
                        break;
                    case 3:
                        enemyAdd = new FlyingRat(enemyAssets[1, 0]);
                        enemyAdd.EnemyType = 5;
                        enemyAdd.Health = 10;
                        enemyAdd.Speed = 3;
                        enemyAdd.Damage = 1;
                        break;
                }
                if (enemyAdd == null)
                {
                    Console.WriteLine("Error getting enemy");
                    return;
                }
                enemyAdd.Pos = new Vector2(charRec.X, charRec.Y);
                enemyAdd.HitBox = new Rectangle((int)(enemyAdd.Pos.X), (int)(enemyAdd.Pos.Y), enemyAssets[enemySelectIndex, 0].Width, enemyAssets[enemySelectIndex, 0].Height);
                Enemy[] newEnemies = new Enemy[enemies[currentFloor].Length + 1];
                for (int i = 0; i < enemies[currentFloor].Length; i++)
                {
                    newEnemies[i] = enemies[currentFloor][i];
                }
                newEnemies[newEnemies.Length - 1] = enemyAdd;

                enemies[currentFloor] = newEnemies;
            }
        }

        private void checkRemoveSelect(MouseState mouse)
        {
            Rectangle mouseRec = new Rectangle(mouse.X, mouse.Y, 1, 1);

            if (mouseRec.Intersects(removeRec))
            {
                removeSelect = true;
                if (mouse.LeftButton == ButtonState.Pressed && !mouseDown)
                {
                    currentTile = -1;
                    currentTileRec = new Rectangle(0, 0, 0, 0);
                    enemySelectIndex = -1;
                    selectingEnemy = false;
                    selectingEnemyIndex = -1;
                    removingEnemy = !removingEnemy;
                }
            }
            else
            {
                removeSelect = false;
            }
        }

        private void removeEnemy(MouseState mouse)
        {
            Rectangle mouseRec = new Rectangle(mouse.X, mouse.Y, 1, 1);
            bool hit = false;
            for (int i = 0; i < enemies[currentFloor].Length; i++)
            {
                if (mouseRec.Intersects(enemies[currentFloor][i].HitBox))
                {
                    hit = true;
                    
                    enemySelectIndex = i;
                    if (mouse.LeftButton == ButtonState.Pressed && !mouseDown)
                    {
                        Enemy[] newList = new Enemy[enemies[currentFloor].Length - 1];
                        for (int j = 0; j < enemies[currentFloor].Length; j++)
                        {
                            if (j < enemySelectIndex)
                            {
                                newList[j] = enemies[currentFloor][j];
                            }
                            else if (j > enemySelectIndex)
                            {
                                newList[j - 1] = enemies[currentFloor][j];
                            }
                        }

                        enemies[currentFloor] = newList;
                    }
                }
            }
            if (hit == false)
            {
                enemySelectIndex = -1;
            }
        }

        //==========================================    update  ==========================================
        public void UpdateEditor(MouseState mouse, GraphicsDevice graphics)
        {

            //find the tile your moues is over
            if (!selectingEnemy && !removingEnemy)
            {
                getTile(mouse);
            }
            
            getSelectTile(mouse);

            //check to see if the mouse is over any text
            //-deal with changing tint colors
            //-deal with mouse press/action when clicking text
            checkSaveSelect(mouse, graphics);
            checkNewFloorSelect(mouse, graphics);
            checkFloorSelect(mouse, graphics);
            checkUpSelect(mouse, graphics);
            checkDownSelect(mouse, graphics);
            checkEnemySelct(mouse, graphics);
            checkRemoveSelect(mouse);

            if (selectingEnemy)
            {
                CheckEnemyPlacement(mouse, graphics);
            }

            if (removingEnemy)
            {
                removeEnemy(mouse);
            }

            if (mouse.LeftButton == ButtonState.Pressed)
            {
                mouseDown = true;
            } 
            else
            {
                mouseDown = false;
            }
            
        }
        //==========================================    draw    ==========================================
        public void DrawEditor(GraphicsDevice graphics, SpriteBatch spriteBatch, SpriteFont font, Game1 one)
        {
            MouseState mouse = Mouse.GetState();
            
            drawTiles(graphics, spriteBatch);

            int loopNum = 0;
            for (int i = 0; i < floorAssets.Length; i++)
            {
                if (i == 19 || i == 20)
                {
                    //do nothing
                }
                else
                {
                    spriteBatch.Draw(floorAssets[i], tileSelect[loopNum], Color.White);

                    loopNum++;
                }

            }

            spriteBatch.Draw(assets[1], currentTileRec, Color.White);

            if (selectedTile != null)
            {
                spriteBatch.Draw(assets[1], selectingTile, Color.White);
            }

            int showFloors = topLevel + 10;
            if (topLevel + 10 > floors.Count)
            {
                showFloors = floors.Count - topLevel;
            }
            for (int i = topLevel; i < showFloors; i++)
            {
                Color tintColor = Color.White;
                
                if (floorTextSelect == i)
                {
                    tintColor = Color.Yellow;
                }
                if (currentFloor == i)
                {
                    tintColor = Color.YellowGreen;
                }
                string text = "Level - " + i;
                if (i == 0)
                {
                    text = "Default Floor";
                }
                spriteBatch.DrawString(font, text, new Vector2(floorText[i].X, floorText[i].Y), tintColor);
            }

            
            Color tint = Color.White;
            int count = 0;
            for (int i = 0; i < enemySelect.Count; i++)
            {
                tint = Color.White;

                if (selectingEnemyIndex == i)
                {
                    tint = Color.Yellow;
                }
                if (enemySelectIndex == i && !removingEnemy)
                {
                    tint = Color.YellowGreen;
                }

                if (i == 2)
                {
                    count++;
                }
                spriteBatch.Draw(enemyAssets[count, 0], enemySelect[i], tint);

                count++;
            }


            tint = checkText(saveSelect);
            spriteBatch.DrawString(font, "Save Floor", new Vector2(saveBox.X, saveBox.Y), tint);

            tint = checkText(newFloorSelect);
            spriteBatch.DrawString(font, "- New Floor -", new Vector2(newFloor.X, newFloor.Y), tint);

            tint = checkText(upSelect);
            spriteBatch.DrawString(font, "[UP]", new Vector2(up.X, up.Y), tint);

            tint = checkText(downSelect);
            spriteBatch.DrawString(font, "[DOWN]", new Vector2(down.X, down.Y), tint);


            for (int i = 0; i < enemies[currentFloor].Length; i++)
            {
                Color enemyTint = Color.White;
                if (enemySelectIndex == i && removingEnemy)
                {
                    enemyTint = Color.Red;
                }
                int enemyID = 0;
                if (enemies[currentFloor][i].EnemyType == 5)
                {
                    enemyID = 3;
                }
                else
                {
                    enemyID = enemies[currentFloor][i].EnemyType;
                }
                spriteBatch.Draw(enemyAssets[enemyID, 0], enemies[currentFloor][i].Pos, enemyTint);
            }

            tint = Color.White;
            if (removeSelect)
            {
                tint = Color.Yellow;
            }
            spriteBatch.Draw(assets[2], removeRec, tint);

            if (selectingEnemy)
            {
                tint = Color.White;
                if (!canPlaceEnemy)
                {
                    tint = Color.Red;
                }
                Texture2D enemy = enemyAssets[enemySelectIndex, 0];
                spriteBatch.Draw(enemy, new Vector2(mouse.X-(enemy.Width/2), mouse.Y - (enemy.Height / 2)), tint);
            }

            if (removingEnemy)
            {
                tint = Color.White;
                spriteBatch.Draw(assets[2], new Vector2(mouse.X - 25, mouse.Y - 25), tint);
            }

            if (currentFloor >= enemies.Count)
            {
                Enemy[] enemyAdd = new Enemy[0];
                enemies.Add(enemyAdd);
            }


            spriteBatch.DrawString(font, "Enemy Placement: ", new Vector2(enemySelect[0].X - 300, enemySelect[0].Y + (enemySelect[0].Height/4)), Color.White);

            spriteBatch.DrawString(font, "Tile Placement: ", new Vector2(tileSelect[0].X - 25, tileSelect[0].Y - 50), Color.White);
            Game1 g = one;
            g.DrawLevelMain();
        }
        
        private Color checkText(bool test)
        {
            Color tint = Color.White;
            if (test)
            {
                tint = Color.Yellow;
            }

            return tint;
        }

        private void getTile(MouseState mouse)
        {
            bool foundTile = false;

            for (int i = 1; i < FLOOR_HEIGHT - 1; i++)
            {
                for (int l = 1; l < FLOOR_WIDTH - 1; l++)
                {
                    if (floorBounds[i, l].Intersects(new Rectangle(mouse.X, mouse.Y, 1, 1)))
                    {
                        selectedTile[0] = i;
                        selectedTile[1] = l;
                        foundTile = true;
                        if (mouse.LeftButton == ButtonState.Pressed)
                        {
                            floor[i, l] = currentTile;
                        }
                    }
                }
            }

            if (!foundTile)
            {
                selectedTile[0] = -1;
                selectedTile[1] = -1;
            }
        }

        private void getSelectTile(MouseState mouse)
        {
            int index = 0;
            bool found = false;

            foreach (var item in tileSelect)
            {
                if (new Rectangle(mouse.X, mouse.Y, 1, 1).Intersects(item))
                {
                    selectingTile = item;
                    found = true;
                    if (index >= 19)
                    {
                        index += 2;
                    }
                    if (mouse.LeftButton == ButtonState.Pressed)
                    {
                        selectingEnemy = false;
                        selectingEnemyIndex = -1;
                        enemySelectIndex = -1;
                        currentTile = index;
                        currentTileRec = item;
                        removingEnemy = false;
                    }
                }
                index++;
            }
            if (!found)
            {
                selectingTile = new Rectangle(0, 0, 0, 0);
            }
        }

        public void SaveFile(GraphicsDevice graphics)
        {
            if (currentFloor == 0 && floors.Count == 0)
            {
                floors.Add(floor);
                updateLevelText(graphics);
            }

            try
            {
                StreamWriter writer = new StreamWriter("Floors.json");
                string data = JsonConvert.SerializeObject(floors);
                writer.WriteLine(data);
                writer.Close();
            }
            catch(Exception ex)
            {
                Console.WriteLine("Writting Floor error: \n"+ex+"\n\n");
            }

            try
            {
                StreamWriter writer = new StreamWriter("EnemySpawn.json");
                string data = JsonConvert.SerializeObject(enemies);
                writer.Write(data);
                writer.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Writting EnemySpawns error: \n" + ex + "\n\n");
            }
        }

        public void LoadFiles()
        {
            try
            {
                StreamReader reader = new StreamReader("Floors.json");
                string data = reader.ReadToEnd();
                List<int[,]> floorGet = JsonConvert.DeserializeObject<List<int[,]>>(data);
                floors = floorGet;
                reader.Close();
            }
            //look to see if file isn't found
            catch (FileNotFoundException)
            {
                Console.WriteLine("Floor file was deleted? Please redownload file");
            }
            //catch any other exceptions that might be thrown
            catch (Exception ex)
            {
                Console.WriteLine("Error attempting to read Floor file/deserialize json:\n" + ex+"\n\n");
            }

            try
            {
                StreamReader reader = new StreamReader("EnemySpawn.json");
                string data = reader.ReadToEnd();
                List<Enemy[]> enemyGet = JsonConvert.DeserializeObject<List<Enemy[]>>(data);
                enemies = enemyGet;
                reader.Close();
            }
            catch (FileNotFoundException)
            {
                Console.WriteLine("Enemy Spawn file was deleted? Please redownload file");
            }
            //catch any other exceptions that might be thrown
            catch (Exception ex)
            {
                Console.WriteLine("Error attempting to read Enemy Spawn file/deserialize json:\n" + ex + "\n\n");
            }
        }

        private void drawTiles(GraphicsDevice graphics, SpriteBatch spriteBatch)
        {
            int height = 0;
            int width = 0;
            Rectangle floorRec = new Rectangle(0, 0, (graphics.Viewport.Width / FLOOR_WIDTH) * 2 / 3, (graphics.Viewport.Height / FLOOR_HEIGHT) * 2 / 3);
            foreach (var item in floor)
            {
                floorRec.X = ((graphics.Viewport.Width / FLOOR_WIDTH) * 2 / 3) * width + ((graphics.Viewport.Width / 3) / 2);
                floorRec.Y = ((graphics.Viewport.Height / FLOOR_HEIGHT) * 2 / 3) * height + ((graphics.Viewport.Height / 3) / 2);
                if (firstRun)
                    floorBounds[height, width] = floorRec;
                spriteBatch.Draw(floorAssets[floor[height, width]], floorRec, Color.White);
                if (height == selectedTile[0] && width == selectedTile[1] && !selectingEnemy && !removingEnemy)
                {
                    spriteBatch.Draw(assets[1], floorRec, Color.White);
                }
                else
                {
                    spriteBatch.Draw(assets[0], floorRec, Color.White);
                }
                width++;
                if (width == FLOOR_WIDTH)
                {
                    width = 0;
                    height++;
                }
            }
            if (firstRun)
            {
                int size = 50;

                tileSelect = new List<Rectangle>();
                int loopNum = 0;
                for (int i = 0; i < floorAssets.Length; i++)
                {
                    if (i == 18 || i == 19)
                    {
                        //do nothing (dont show these tiles)
                    }
                    else
                    {
                        int x = floorBounds[0, FLOOR_WIDTH - 1].X + floorBounds[0, FLOOR_WIDTH - 1].Height + size;
                        int y = floorBounds[0, FLOOR_WIDTH - 1].Y + size;
                        tileSelect.Add(new Rectangle(x + ((size + 5) * (loopNum % 3)), y + (loopNum / 3) * (size + 5), size, size));
                        loopNum++;
                    }
                }
                currentTile = 0;
                currentTileRec = tileSelect[0];
                firstRun = false;

                int xPlace = floorBounds[1, 1].X;
                int yPlace = floorBounds[1, 1].Y;
                placementRec = new Rectangle(xPlace, yPlace, floorBounds[FLOOR_HEIGHT-2, FLOOR_WIDTH - 2].Right - xPlace, floorBounds[FLOOR_HEIGHT - 2, FLOOR_WIDTH-2].Bottom - yPlace);
            }
        }
    }
}
