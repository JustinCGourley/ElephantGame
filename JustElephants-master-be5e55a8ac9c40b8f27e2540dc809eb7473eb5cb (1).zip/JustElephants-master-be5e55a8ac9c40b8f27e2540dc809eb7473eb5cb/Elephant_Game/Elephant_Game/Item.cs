﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Elephant_Game
{
    class Item
    {
        public bool PickedUp { get; set; }
        public Rectangle Pos { get; set; }
        public int Type { get; set; }

        public Item(Rectangle pos, int type)
        {
            Pos = pos;
            Type = type;
        }

        public virtual void function(Player player)
        {
            //override this to do something for the player
        }
    }
}
