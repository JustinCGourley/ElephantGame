﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace Elephant_Game
{
    /// <summary>
    /// Player Class
    /// </summary>
    /// Tracks health, speed, shotspeed, range, and damage
    class Player
    {
        //player position
        public Vector2 Pos;
        public Vector2 Origin;
        public float rotation;
        //collision checks
        bool[] allowMove = new bool[4];
        public int AnimationState { get; set; }
        private int animationTick = 0;
        //player stats
        public int HealthSlots { get; set; }
        public int CurrentHealth { get; set; }
        public double CurrentWater { get; set; }
        public double MaxWater { get; set; }
        public int Speed { get; set; }
        public int ShotSpeed { get; set; }
        public int BulletSpeed { get; set; }
        public int Range { get; set; }
        public int Damage { get; set; }
        public bool dead = false;
        //player image
        public Texture2D playerImage { get; set; }
        public Texture2D puddleSpace { get; set; }
        int waterGainTick = 0;
        public int WaterGain { get; set; }
        public Rectangle HitBox { get; set; }
        public int UpgradePoints { get; set; }
        public int?[] Upgrades { get; set; }
        public int Iframes { get; set; }
        Collisions collisions = new Collisions();
        SoundManager soundManager;
        private int[] animationSlide = { 0, 1, 0, 2 };
        private int currentSlide = 0;
        private int shotTick = 0;
        

        public Player()
        {
            Iframes = 0;
            Upgrades = null;
            UpgradePoints = 0;
            //set-up player Position
            Pos = new Vector2(0f, 0f);
            //set-up origin point
            Origin = new Vector2(62 / 2 - 10, 81 / 2);
            animationTick = 0;
            AnimationState = 0;
        }

        public Player(float x, float y, SoundManager sm)
        {
            Iframes = 0;
            Upgrades = null;
            UpgradePoints = 0;
            Pos = new Vector2(x, y);
            //set-up origin point
            Origin = new Vector2(62 / 2 - 10, 81 / 2);
            soundManager = sm;
            animationTick = 0;
            AnimationState = 0;
        }

        public void Update()
        {
            MovePlayer();
            UpdateRotation();
            UpdateTick();
            if (Iframes > 0)
            {
                Iframes--;
            }
            HitBox = new Rectangle((int)(Pos.X - playerImage.Height/3), (int)(Pos.Y - playerImage.Height/3), (int)(playerImage.Height * 0.75), (int)(playerImage.Height * 0.75));
        }

        public void MovePlayer()
        {
            //allow movement for player
            KeyboardState key = Keyboard.GetState();

            //0 = up, 1 = left, 2 = down, 3 = right
            bool move = false;
            if (key.IsKeyDown(Keys.W))
            {
                if (allowMove[0])
                {
                    Pos.Y -= Speed;
                    move = true;
                }
            }
            if (key.IsKeyDown(Keys.A))
            {
                if (allowMove[1])
                {
                    Pos.X -= Speed;
                    move = true;
                }
            }
            if (key.IsKeyDown(Keys.S))
            {
                if (allowMove[2])
                {
                    Pos.Y += Speed;
                    move = true;
                }
            }
            if (key.IsKeyDown(Keys.D))
            {
                if (allowMove[3])
                {
                    Pos.X += Speed;
                    move = true;
                }
            }
            if (move)
            {
                animationTick++;
                if (animationTick >= 10)
                {
                    animationTick = 0;
                    currentSlide++;
                    if (currentSlide >= animationSlide.Length)
                    {
                        currentSlide = 0;
                    }
                    AnimationState = animationSlide[currentSlide];
                }
            }
            else
            {
                AnimationState = 0;
                animationTick = 5;
            }
        }

        public void UpdateRotation()
        {
            try
            {
                MouseState mouse = Mouse.GetState();
                Vector2 mouseVec = new Vector2(mouse.X, mouse.Y);
                Vector2 playerPos = new Vector2(Pos.X, Pos.Y);
                Vector2 direction = mouseVec - playerPos;
                float angle = (float)Math.Atan2(-direction.Y, -direction.X);

                angle += (float)(Math.PI * 0.5f);
                rotation = angle;
            } catch (Exception ex)
            {
                Console.WriteLine("!-Rotation Update Error occured-!\n" + ex);
            }
        }

        private void UpdateTick()
        {
            if (shotTick != 0)
            {
                shotTick--;
            }
        }

        public Bullet Shoot()
        {
            Bullet shot = null;

            if (CurrentWater > 0)
            {
                if (shotTick <= 0)
                {
                    double X = -(Math.Sin(rotation));
                    double Y = Math.Cos(rotation);
                    Vector2 direction = new Vector2((float)(X * BulletSpeed), (float)(Y * BulletSpeed));
                    shot = new Bullet()
                    {
                        Lifespan = Range,
                        Damage = this.Damage,
                        Direction = direction,
                        Loc = Pos,
                        Rotation = (float)(rotation - (Math.PI * 1.5))
                    };

                    shotTick = ShotSpeed;
                    CurrentWater--;
                }
            }

            if (CurrentWater<= 0)
            {
                CurrentWater = 0;
            }

            return shot;
        }

        //checks for a collision with a rat that is passed in
        public void playerHit(Rectangle enemy)
        {
            if (Iframes > 0)
            {
                return;
            }

            if(HitBox.Intersects(enemy))
            {
                soundManager.playSound("ugh");
                CurrentHealth--;
                Iframes = 60;
                if(CurrentHealth <= 0)
                {
                    dead = true;
                }
            }
        }

        //check collision with spike pit
        public void playerHit()
        {
            if (Iframes > 0)
            {
                return;
            }
            soundManager.playSound("ugh");
            CurrentHealth--;
            Iframes = 60;
            if (CurrentHealth <= 0)
            {
                dead = true;
            }
        }

        public void CheckAllowMove(Rectangle[,] floorRec, int[,] floors, int maxWidth, int maxHeight, int tileWidth, int tileHeight)
        {
            allowMove[0] = true;
            allowMove[1] = true;
            allowMove[2] = true;
            allowMove[3] = true;
            

            int playerWidth = (int)Pos.X / (maxWidth / tileWidth);
            int playerHeight = (int)Pos.Y / (maxHeight / tileHeight);

            try
            {
                //check tile you are on
                if (collisions.checkMove(floors[playerHeight, playerWidth]))
                {
                    //get middle for X and Y of current tile
                    int xMid = floorRec[playerHeight, playerWidth].X + (floorRec[playerHeight, playerWidth].Width / 2);
                    int yMid = floorRec[playerHeight, playerWidth].Y + (floorRec[playerHeight, playerWidth].Height / 2);
                    //stop movement
                    allowMove[0] = false;
                    allowMove[1] = false;
                    allowMove[2] = false;
                    allowMove[3] = false;

                    //X Push
                    if (Pos.X > xMid)
                    {
                        Pos.X++;
                    }
                    else
                    {
                        Pos.X--;
                    }
                    //Y Push
                    if (Pos.Y > yMid)
                    {
                        Pos.Y++;
                    }
                    else
                    {
                        Pos.Y--;
                    }
                }
            } catch 
            {}

            //check floor above you 
            try
            {
                if (collisions.checkMove(floors[playerHeight - 1, playerWidth]))//check for rocks and walls
                {
                    if (Pos.Y - (playerImage.Width*0.85) <= floorRec[playerHeight - 1, playerWidth].Bottom)
                    {
                        allowMove[0] = false;
                        if ((Pos.Y - (playerImage.Width * 0.85)) + 1 < floorRec[playerHeight - 1, playerWidth].Bottom)
                        {
                           Pos.Y = floorRec[playerHeight - 1, playerWidth].Bottom + (playerImage.Bounds.Width - 7);
                        }

                    }
                }
            } catch
            {}

            //checks floor below you
            try
            {
                if (collisions.checkMove(floors[playerHeight + 1, playerWidth]))
                {
                    if (Pos.Y + playerImage.Width >= floorRec[playerHeight + 1, playerWidth].Y)
                    {
                        allowMove[2] = false;
                        if (Pos.Y + playerImage.Width > floorRec[playerHeight + 1, playerWidth].Y)
                        {
                            Pos.Y = floorRec[playerHeight + 1, playerWidth].Y - (playerImage.Bounds.Width);
                        }
                    }
                }
            }catch 
            {}

            //checks floor to the left of you
            try
            {
                if (collisions.checkMove(floors[playerHeight, playerWidth - 1]))
                {
                    if (Pos.X - playerImage.Width <= floorRec[playerHeight, playerWidth - 1].Right)
                    {
                        allowMove[1] = false;
                        if (Pos.X - playerImage.Width < floorRec[playerHeight, playerWidth - 1].Right)
                        {
                            Pos.X = floorRec[playerHeight, playerWidth - 1].Right + (playerImage.Bounds.Width);
                        }
                    }
                }
            } catch 
            {}

            //checks floor to the right of you
            try
            {
                if (collisions.checkMove(floors[playerHeight, playerWidth + 1]))
                {
                    if (Pos.X + playerImage.Width >= floorRec[playerHeight, playerWidth + 1].X)
                    {
                        allowMove[3] = false;
                        if (Pos.X + playerImage.Width > floorRec[playerHeight, playerWidth + 1].X)
                        {
                            Pos.X = floorRec[playerHeight, playerWidth + 1].X - (playerImage.Bounds.Width);
                        }
                    }
                }
            } catch
            {}
        }

        public int GetCurentFloor(int[,] floors, int maxWidth, int maxHeight, int tileWidth, int tileHeight)
        {
            try
            {
                int playerWidth = (int)Pos.X / (maxWidth / tileWidth);
                int playerHeight = (int)Pos.Y / (maxHeight / tileHeight);

                return floors[playerHeight, playerWidth];
            }
            catch 
            {
                return 0;
            }
        }

        //add water to player when standing on puddle
        public void GainWater(bool roomEmpty)
        {
            if (waterGainTick <= 0)
            {
                waterGainTick = WaterGain;
                if (CurrentWater < MaxWater)
                {
                    if (roomEmpty)
                    {
                        CurrentWater += 3;
                    }
                    else
                    {
                        CurrentWater++;
                    }
                }
                if (CurrentWater > MaxWater)
                {
                    CurrentWater = MaxWater;
                }
            }
            else
            {
                waterGainTick--;
            }
        }
        

    }
}
