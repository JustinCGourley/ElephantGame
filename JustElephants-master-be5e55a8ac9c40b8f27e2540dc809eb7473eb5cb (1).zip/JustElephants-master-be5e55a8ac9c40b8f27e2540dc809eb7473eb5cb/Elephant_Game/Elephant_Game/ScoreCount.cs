﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Elephant_Game
{
    class ScoreCount
    {

        public int Score { get; set; }
        bool stopKey = false;
        Random ran = new Random();
        public int Timer { get; set; }
        public int Ticks { get; set; }
        TimeSpan time, pausedTime;
        DateTime startTime = DateTime.Now;
        public TimeSpan TotalTime { get; set; }

        public void AddScore(int amount)
        {
            Score += amount;
        }

        public void DrawScore(SpriteFont scoreFont, SpriteBatch spriteB, GraphicsDevice graphicsD)
        {
            float x = (graphicsD.Viewport.Width/10) * 7;
            string scoreString = "Score: " + Score;
            
            spriteB.DrawString(scoreFont, scoreString, new Vector2(x - 20, 20), Color.White);
        }

        public void checkUpgrade(Player player)
        {
            if (player.UpgradePoints <= 0)
            {
                return;
            }

            if (player.Upgrades == null)
            {
                player.Upgrades = new int?[7];
                player.Upgrades[0] = ran.Next(0, 6); //damage
                player.Upgrades[1] = ran.Next(0, 4); //speed
                player.Upgrades[2] = ran.Next(1, 3); //max water
                player.Upgrades[3] = ran.Next(0, 4); //water gain
                player.Upgrades[4] = ran.Next(0, 6); //shot speed
                player.Upgrades[5] = ran.Next(1, 11); //range
                player.Upgrades[6] = ran.Next(1, 6); //bullet speed

                if (player.Speed + player.Upgrades[1] > 15)
                {
                    player.Upgrades[1] = 15 - player.Speed;
                    if (player.Upgrades[1] < 0)
                    {
                        player.Upgrades[1] = 0;
                    }
                }
                if (player.WaterGain - player.Upgrades[3] < 0)
                {
                    player.Upgrades[3] = player.WaterGain;
                    if (player.Upgrades[3] < 0)
                    {
                        player.Upgrades[3] = 0;
                    }
                }
                if (player.ShotSpeed - player.Upgrades[4] < 0)
                {
                    player.Upgrades[4] = player.ShotSpeed;
                    if (player.Upgrades[4] < 0)
                    {
                        player.Upgrades[4] = 0;
                    }
                }
            }

            KeyboardState key = Keyboard.GetState();

            if (key.IsKeyDown(Keys.D1) && !stopKey && player.Upgrades[0] != 0)
            {
                player.Damage += (int)player.Upgrades[0];
                stopKey = true;
                player.Upgrades = null;
                player.UpgradePoints--;
                AddScore(-50);
            }
            else if (key.IsKeyDown(Keys.D2) && !stopKey && player.Upgrades[1] != 0)
            {
                player.Speed += (int)player.Upgrades[1];
                stopKey = true;
                player.Upgrades = null;
                player.UpgradePoints--;
                AddScore(-50);
            }
            else if (key.IsKeyDown(Keys.D3) && !stopKey)
            {
                player.MaxWater += (int)player.Upgrades[2];
                stopKey = true;
                player.Upgrades = null;
                player.UpgradePoints--;
                AddScore(-50);
            }
            else if (key.IsKeyDown(Keys.D4) && !stopKey && player.Upgrades[3] != 0)
            {
                player.WaterGain -= (int)player.Upgrades[3];
                stopKey = true;
                player.Upgrades = null;
                player.UpgradePoints--;
                AddScore(-50);
            }
            else if (key.IsKeyDown(Keys.D5) && !stopKey && player.Upgrades[4] != 0)
            {
                player.ShotSpeed -= (int)player.Upgrades[4];
                stopKey = true;
                player.Upgrades = null;
                player.UpgradePoints--;
                AddScore(-50);
            }
            else if (key.IsKeyDown(Keys.D6) && !stopKey)
            {
                player.Range += (int)player.Upgrades[5];
                stopKey = true;
                player.Upgrades = null;
                player.UpgradePoints--;
                AddScore(-50);
            }
            else if (key.IsKeyDown(Keys.D7) && !stopKey)
            {
                player.BulletSpeed += (int)player.Upgrades[6];
                stopKey = true;
                player.Upgrades = null;
                player.UpgradePoints--;
                AddScore(-50);
            }
            if (key.IsKeyUp(Keys.D1) && key.IsKeyUp(Keys.D2) && key.IsKeyUp(Keys.D3) && key.IsKeyUp(Keys.D4) && key.IsKeyUp(Keys.D5) && key.IsKeyUp(Keys.D6) && key.IsKeyUp(Keys.D7))
            {
                stopKey = false;
            }
        }

        public void DrawStats(SpriteFont statFont, Player player, SpriteBatch spriteB, GraphicsDevice graphicsD)
        {
            if (player.Upgrades == null)
            {
                return;
            }
            string damage = player.Damage + "          + " + player.Upgrades[0];
            if (player.Upgrades[0] == 0)
                damage = "" + player.Damage;
            string speed = player.Speed + "           + " + player.Upgrades[1];
            if (player.Upgrades[1] == 0)
                speed = "" + player.Speed;
            string waterGain = player.WaterGain + "     - " + player.Upgrades[3];
            if (player.Upgrades[3] == 0)
                waterGain = "" + player.WaterGain;
            string shotSpeed = player.ShotSpeed + "     - " + player.Upgrades[4];
            if (player.Upgrades[4] == 0)
                shotSpeed = "" + player.ShotSpeed;



            string text = "Upgrade Points Left: " + player.UpgradePoints + "\n"
                      + "\n(1) Damage: " + damage
                      + "\n(2) Speed: " + speed
                      + "\n(3) Max Water: " + player.MaxWater + "     + " + player.Upgrades[2]
                      + "\n(4) Water Gain: " + waterGain
                      + "\n(5) Shot Speed: " + shotSpeed
                      + "\n(6) Range: " + player.Range + "            + " + player.Upgrades[5]
                      + "\n(7) Bullet Speed: " + player.BulletSpeed + "    + " + player.Upgrades[6]; 
            spriteB.DrawString(statFont, text, new Vector2(player.Pos.X + 50, player.Pos.Y - 50), Color.White);
        }

        public void TimerCount(SpriteFont timeFont, SpriteBatch spriteB, GraphicsDevice graphics, int level, bool paused)
        {

            if (paused)
            {
                TimeSpan timeToAdd = new TimeSpan(166667);
                pausedTime += timeToAdd;
            }

            //time passed
            time = DateTime.Now - startTime;
            time -= pausedTime;

            TotalTime = time;

            string timeText = "";
            if (time.Hours < 10)
                timeText += "0" + time.Hours + ":";
            else
                timeText += time.Hours + ":";
            if (time.Minutes < 10)
                timeText += "0" + time.Minutes + ":";
            else
                timeText += time.Minutes + ":";
            if (time.Seconds < 10)
                timeText += "0" + time.Seconds;
            else
                timeText += time.Seconds;

            timeText += "     Level: " + (level);


            spriteB.DrawString(timeFont, timeText, new Vector2(35, graphics.Viewport.Height - 70), Color.White);
        }
    }
}
