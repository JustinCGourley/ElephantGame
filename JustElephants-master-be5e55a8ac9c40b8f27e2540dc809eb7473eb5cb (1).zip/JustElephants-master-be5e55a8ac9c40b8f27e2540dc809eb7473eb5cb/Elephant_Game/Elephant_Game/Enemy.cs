﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework.Input;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace Elephant_Game
{
    class Enemy
    {
        // enemy position, origin, rotation
        public Vector2 Pos;
        public Vector2 Origin;
        public float rotation; 

        

        // enemy stats 
        public double Health { get; set; }
        public int Speed { get; set; }
        public int Damage { get; set; }
        public Rectangle HitBox;
        public bool Dead = false;
        private bool[] stopMovement = new bool[4];
        private bool[] blocked = new bool[4];
        // enemy image
        [JsonIgnore]
        public Texture2D EnemyImage { get; set; }
        public int EnemyPicNum { get; set; }
        public int AnimationState { get; set; }
        private int animationTick;
        public int EnemyType { get; set; }
        private int currentSlide = 0;
        private int[] animationSlide = { 0, 1, 0, 2 };

        Collisions enemyCollision = new Collisions();

        public Enemy()
        {
        }

        public Enemy(Texture2D enemyImage)
        {
            EnemyImage = enemyImage;
            Pos = new Vector2(100f, 100f);
            HitBox = new Rectangle((int)Pos.X, (int)Pos.Y, 60, 60);
            Origin = new Vector2(EnemyImage.Width / 2, EnemyImage.Height / 2);
        }

        public Enemy(int xPos, int yPos, Texture2D enemyImage)
        {
            EnemyImage = enemyImage;
            HitBox = new Rectangle((int)Pos.X, (int)Pos.Y, 60, 60);
            Origin = new Vector2(EnemyImage.Width / 2, EnemyImage.Height / 2);
        }

        public virtual void UpdateEnemy(Player play, List<Enemy> enemies, List<Rectangle> floorCollisions)
        {
            // always face player, move towards player
            RotateTowardsEnemy(play);
            checkWorldMovement(floorCollisions);
            TrackPlayer(play);

            HitBox = new Rectangle((int)Pos.X - 30, (int)Pos.Y - 30, 60, 60);
            checkIntersection(enemies);

            
        }

        public virtual void UpdateAnimation()
        {
            animationTick++;
            if (animationTick >= 10)
            {
                animationTick = 0;
                currentSlide++;
                if (currentSlide >= animationSlide.Length)
                {
                    currentSlide = 0;
                }
                AnimationState = animationSlide[currentSlide];

            }
        }

        public virtual void checkWorldMovement(List<Rectangle> floorCollisions)
        {
            bool hitTop = false, hitSide = false;
            foreach (var item in floorCollisions)
            {
                if (HitBox.Intersects(item))
                {
                    //left
                    if ((HitBox.Left < item.Right) && (HitBox.Left > item.Left))
                    {
                        blocked[0] = true;
                        blocked[1] = false;
                        hitTop = true;
                    }
                    //right
                    else if ((HitBox.Right > item.Left) && (HitBox.Right < item.Right))
                    {
                        blocked[1] = true;
                        blocked[0] = false;
                        hitTop = true;
                    }
                    //down
                    if ((HitBox.Bottom < item.Bottom) && (HitBox.Bottom > item.Top))
                    {
                        blocked[2] = true;
                        blocked[3] = false;
                        hitSide = true;
                    }
                    //up
                    else if ((HitBox.Top > item.Top) && (HitBox.Top < item.Bottom))
                    {
                        blocked[3] = true;
                        blocked[2] = false;
                        hitSide = true;
                    }
                }
            }

            if (!hitTop)
            {
                blocked[2] = false;
                blocked[3] = false;
            }
            if (!hitSide)
            {
                blocked[0] = false;
                blocked[1] = false;
            }
        }
        
        public virtual void TrackPlayer(Player player)
        {
            float angle = getAngle(player);
            double X = -(Math.Sin(angle));
            double Y = Math.Cos(angle);
            Vector2 direction = new Vector2((float)(X * Speed), (float)(Y * Speed));

            //check enemy collisions
            if ((direction.X < 0 && stopMovement[0]) || (direction.X > 0 && stopMovement[1]))
            {
                direction.X = 0;
            }

            if ((direction.Y < 0 && stopMovement[3]) || (direction.Y > 0 && stopMovement[2]))
            {
                direction.Y = 0;
            }

            //check world collisions
            direction = worldCollisionTest(direction, player);



            Pos.X += direction.X;
            Pos.Y += direction.Y;
        }

        private Vector2 worldCollisionTest(Vector2 direction, Player player)
        {
            //check left/right
            if (direction.X < 0 && blocked[0])
            {
                direction.X = 0;
                if (player.Pos.Y < Pos.Y)
                {
                    direction.Y = (direction.Y / 2) - (Speed / 2);
                }
                else if (player.Pos.Y > Pos.Y)
                {
                    direction.Y = (direction.Y / 2) + (Speed / 2);
                }
            }
            else if (direction.X > 0 && blocked[1])
            {
                direction.X = 0;
                if (player.Pos.Y < Pos.Y)
                {
                    direction.Y = (direction.Y / 2) - (Speed / 2);
                }
                else if (player.Pos.Y > Pos.Y)
                {
                    direction.Y = (direction.Y / 2) + (Speed / 2);
                }
            }

            //bottom/Top
            if ((direction.Y > 0 && blocked[2]))
            {
                direction.Y = 0;
                if (player.Pos.X < Pos.X)
                {
                    direction.X = (direction.X / 2) - (Speed / 2);
                }
                else if (player.Pos.X > Pos.X)
                {
                    direction.X = (direction.X / 2) + (Speed / 2);
                }
            }
            else if (direction.Y < 0 && blocked[3])
            {
                direction.Y = 0;
                if (player.Pos.X < Pos.X)
                {
                    direction.X = (direction.X / 2) - (Speed / 2);
                }
                else if (player.Pos.X > Pos.X)
                {
                    direction.X = (direction.X / 2) + (Speed / 2);
                }
            }

            return direction;
        }

        public virtual void checkIntersection(List<Enemy> enemies)
        {
            bool hit = false;
            foreach (var enemy in enemies)
            {
                //skip over itself
                if (!(enemy == this))
                {
                    //see if a enemy is colliding or not
                    if (HitBox.Intersects(enemy.HitBox))
                    {
                        hit = true;
                        //see if have to stop moving left
                        if ((HitBox.Left < enemy.HitBox.Right) && (HitBox.Left > enemy.HitBox.Left))
                        {
                            stopMovement[0] = true;
                            stopMovement[1] = false;
                        }
                        //see if have to stop moving right
                        else if((HitBox.Right > enemy.HitBox.Left) && (HitBox.Right < enemy.HitBox.Right))
                        {
                            stopMovement[1] = true;
                            stopMovement[0] = false;
                        }
                        //see if have to stop moving down
                        else if ((HitBox.Bottom < enemy.HitBox.Bottom) && (HitBox.Bottom > enemy.HitBox.Top))
                        {
                            stopMovement[2] = true;
                            stopMovement[3] = false;
                        }
                        //see if have to stop moving up
                        else if ((HitBox.Top > enemy.HitBox.Top) && (HitBox.Top < enemy.HitBox.Bottom))
                        {
                            stopMovement[3] = true;
                            stopMovement[2] = false;
                        }
                    }
                }
            }

            if (!hit)
            {
                stopMovement = new bool[4];
            }

            //update the hitbox again
            HitBox = new Rectangle((int)Pos.X - 30, (int)Pos.Y - 30, 60, 60);
        }

        private float getAngle(Player player)
        {
            Vector2 pos = new Vector2(Pos.X, Pos.Y);
            Vector2 playerPos = new Vector2(player.Pos.X + 30, player.Pos.Y + 30);
            Vector2 direction = playerPos - pos;
            float angle = (float)Math.Atan2(-direction.Y, -direction.X);
            angle += (float)(Math.PI * 0.5f);
            return angle;
        }

        public virtual void RotateTowardsEnemy(Player play)
        {
            //Vector2 myPos = new Vector2(Pos.X, Pos.Y);
            //Vector2 enemyPos = new Vector2(play.Pos.X, play.Pos.Y);
            float xDis = play.Pos.X - Pos.X;
            float yDis = play.Pos.Y - Pos.Y;
            double angle = Math.Atan2(yDis, xDis);

            rotation = (float)angle;
            rotation -= (float)(Math.PI * 0.5);
        }

        public bool enemyHit(Bullet bullet)
        {          
            //make sure bullet is alive  
            if (bullet.Lifespan <= 0)
            {
                return false;
            }
            //see if the bullet hits
            if (HitBox.Intersects(new Rectangle((int)bullet.Loc.X, (int)bullet.Loc.Y, 30, 30)))
            {
                //remove health based on bullets damage
                Health -= bullet.Damage;
                if (Health <= 0)
                {
                    Dead = true;
                }

                bullet.Lifespan = 0;
                return true;
            }
            return false;
        }
        
    }
}
