﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Elephant_Game
{
    class ExplosionManager
    {

        List<Vector2> position = new List<Vector2>();
        List<int> animationState = new List<int>();
        List<int> animationTick = new List<int>();
        List<int> types = new List<int>();
        List<int> animationPlaybackSpeed = new List<int>();
        List<Texture2D[]> assets = new List<Texture2D[]>();

        public ExplosionManager(Texture2D[,] assets, int[] assetsCount, int[] speeds)
        {
            for (int i = 0; i < assetsCount.Length; i++)
            {
                Texture2D[] textures = new Texture2D[assetsCount[i]];
                for (int j = 0; j < assetsCount[i]; j++)
                {
                    textures[j] = assets[i, j];
                }
                this.assets.Add(textures);
            }

            foreach (var item in speeds)
            {
                animationPlaybackSpeed.Add(item);
            }
        }

        public void Add(Vector2 position, int type)
        {
            this.position.Add(position);
            this.types.Add(type);
            animationTick.Add(0);
            animationState.Add(0);
        }

        public void Update()
        {
            //update all animations
            List<int> deadAnimations = new List<int>();
            for (int i = 0; i < animationTick.Count; i++)
            {
                animationTick[i]++;
                if (animationTick[i] >= animationPlaybackSpeed[types[i]])
                {
                    animationTick[i] = 0;
                    animationState[i]++;
                    if (animationState[i] >= assets[types[i]].Length)
                    {
                        deadAnimations.Add(i);
                        animationState[i] = 0;
                    }
                }
            }

            //kill off dead animations
            foreach (var item in deadAnimations)
            {
                try
                {
                    position.RemoveAt(item);
                    animationState.RemoveAt(item);
                    animationTick.RemoveAt(item);
                    types.RemoveAt(item);
                } catch
                {
                    //errors occur occationally when going inbetween rooms but everything works fine
                }
            }

        }

        public void Draw(SpriteBatch spriteBatch)
        {
            for (int i = 0; i < position.Count; i++)
            {
                //draw the explosions
                spriteBatch.Draw(assets[types[i]][animationState[i]], position[i], Color.White);
            }
        }
    }
}
