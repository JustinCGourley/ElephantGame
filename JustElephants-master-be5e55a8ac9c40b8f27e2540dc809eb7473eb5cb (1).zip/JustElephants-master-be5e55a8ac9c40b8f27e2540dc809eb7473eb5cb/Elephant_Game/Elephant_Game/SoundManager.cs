﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Media;

namespace Elephant_Game
{
    class SoundManager
    {
        Dictionary<string, SoundEffect> soundList = new Dictionary<string, SoundEffect>();
        Dictionary<string, Song> songList = new Dictionary<string, Song>();
        public bool soundActive { get; set; }
        public float Volume { get; set; }
        private bool songPlaying = false;
        public bool SongPlaying { get { return songPlaying; } }
        public float SongVolume { get; set; }
        public string currentSong { get; set; }

        public SoundManager(SoundEffect[] sounds, string[] soundNames, Song[] songs, string[] songNames)
        {
            int loop = 0;
            Volume = 0.3f;
            SongVolume = Volume / 2;
            soundActive = true;
            songPlaying = false;
            

            foreach (var item in sounds)
            {
                soundList.Add(soundNames[loop], sounds[loop]);
                loop++;
            }

            loop = 0;
            foreach (var item in songs)
            {
                songList.Add(songNames[loop], songs[loop]);
                loop++;
            }
        }

        public void playSound(string soundName)
        {
            if (!soundActive)
            {
                return;
            }
            try
            {
                soundList[soundName].Play(Volume, 0, 0);
            }
            catch (Exception ex)
            {
                Console.WriteLine("No Sound found for key '{0}'", soundName);
            }
        }

        public void playSong(string songName)
        {
            if (!soundActive)
            {
                return;
            }
            try
            {
                if (!songPlaying)
                {
                    MediaPlayer.Play(songList[songName]);
                    MediaPlayer.Volume = SongVolume;
                }
                else if (songPlaying)
                {
                    MediaPlayer.Stop();
                    MediaPlayer.Play(songList[songName]);
                    MediaPlayer.Volume = SongVolume;
                }
                songPlaying = true;
                MediaPlayer.IsRepeating = true;
                currentSong = songName;
            }
            catch (Exception ex)
            {
                Console.WriteLine("No Song found for key '{0}'", songName);
            }
        }

        public void pauseSong()
        {
            MediaPlayer.Stop();
            songPlaying = false;
        }

        public void resumeSong()
        {
            MediaPlayer.Resume();
            songPlaying = true;
        }
    }
}