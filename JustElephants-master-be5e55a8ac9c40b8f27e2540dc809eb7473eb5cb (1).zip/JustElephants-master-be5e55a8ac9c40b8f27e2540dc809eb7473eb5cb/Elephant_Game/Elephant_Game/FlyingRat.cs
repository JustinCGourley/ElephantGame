﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Elephant_Game
{
    class FlyingRat : Enemy
    {
        private int shootSpeed;
        private int shotTick;
        private int BulletSpeed { get; set; }
        private int Range { get; set; }
        public bool AbleToShoot { get; set; }

        public FlyingRat(Texture2D enemyImage)
        {
            Damage = 1;
            Range = 60;
            BulletSpeed = 10;
            shootSpeed = 60;
            shotTick = 0;
            this.EnemyImage = enemyImage;
            Origin = new Vector2(EnemyImage.Width / 2, EnemyImage.Height / 2);
        }

        public override void UpdateEnemy(Player player, List<Enemy> enemies, List<Rectangle> floorCollisions)
        {
            // always face player, move towards player
            RotateTowardsEnemy(player);

            Vector2 vec = Pos - player.Pos;

            if (vec.Length() >= 300)
            {
                TrackPlayer(player);
                AbleToShoot = false;
            }
            else
            {
                ShootPlayer(player);
            }

            HitBox = new Rectangle((int)Pos.X - 30, (int)Pos.Y - 30, 60, 60);

            checkIntersection(enemies);
            checkWorldMovement(floorCollisions);

        }

        private void ShootPlayer(Player player)
        {
            float myAngle = getAngle(player);

            if (shotTick <= 0)
            {
                AbleToShoot = true;
                shotTick = shootSpeed;
            }
            if (!AbleToShoot)
            { 
                shotTick--;
            }
        }

        public Bullet Shoot()
        {
            Bullet shot = null;
            
            double X = -(Math.Sin(rotation));
            double Y = Math.Cos(rotation);
            Vector2 direction = new Vector2((float)(X * BulletSpeed), (float)(Y * BulletSpeed));
            shot = new Bullet()
            {
                Lifespan = Range,
                Damage = this.Damage,
                Direction = direction,
                Loc = Pos,
                Rotation = (float)(rotation - (Math.PI * 1.5))
            };
                

            AbleToShoot = false;
            return shot;
        }
            

        private float getAngle(Player play)
        {
            Vector2 pos = new Vector2(Pos.X, Pos.Y);
            Vector2 playerpos = new Vector2(play.Pos.X, play.Pos.Y);
            Vector2 direction = playerpos - pos;

            float angle = (float)Math.Atan2(-direction.Y, -direction.X);
            angle += (float)(Math.PI * 0.5f);

            return angle;
        }
    }
}
