﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Elephant_Game
{
    class Invincible_Pickup : Item
    {
        public Invincible_Pickup(Rectangle pos) : base(pos, 2)
        {
        }

        public override void function(Player player)
        {
            player.Iframes = 600;
            PickedUp = true;
        }
    }
}
