﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace Elephant_Game
{
    class GameLogic
    {
        //neaded for gameover
        public bool noHealth = false;
        //---global var's---
        const int FLOOR_WIDTH = 21, FLOOR_HEIGHT = 11;
        const int ROOM_DELAY = 10;
        //player vars
        Player player;
        Enemy enemy;
        List<Bullet> playerBullets;
        List<Bullet> enemyBullets;
        //floor vars
        public int[,] floor { get; set; }
        public Rectangle[,] floorBounds { get; set; }
        public int EnterGame { get; set; }
        WorldManager worldMan = new WorldManager();
        bool stopMovement = false;
        Texture2D[] floorAssets, playerTextures, bulletTextures, mapTextures, itemTextures;
        Texture2D[,] enemyTextures;
        List<Enemy> enemyList = new List<Enemy>();
        private bool firstRun;
        Rectangle[] bossHealthBar = new Rectangle[2];
        int currentLevel = 0;
        Rectangle nextLevelRec = new Rectangle();
        ScoreCount stats;
        SpriteFont scoreFont;
        SpriteFont statsFont;
        Collisions collisions = new Collisions();
        List<Rectangle> floorCollisions = new List<Rectangle>();
        SoundManager soundManager;
        ItemManager itemMan = new ItemManager();
        Item[] itemList = new Item[0];
        public bool isTransitioning { get; set; }
        public bool initialRun { get; set; }
        public bool Paused = false;
        ExplosionManager explosionManager;
        int bugTick = 0;
        int roomTick = 0;
        bool cheatActive = false;


        public void setUp(GraphicsDevice graphics, Texture2D[] floorAssets, Texture2D[] playerTextures, Texture2D[] bulletTextures, Texture2D[] mapTextures, Texture2D[,] enemyTextures, SpriteFont getScoreFont, SpriteFont getStatFont, SoundManager soundMan, Texture2D[] itemTextures, ExplosionManager exploMan)
        {
            EnterGame = 30;
            if (initialRun)
            {
                currentLevel = 0;
            }
            currentLevel++;
            firstRun = true;
            //initilize bullet list
            playerBullets = new List<Bullet>();
            enemyBullets = new List<Bullet>();
            //initialize floor bounds and floor
            floorBounds = new Rectangle[FLOOR_HEIGHT, FLOOR_WIDTH];
            floor = new int[FLOOR_HEIGHT, FLOOR_WIDTH];

            soundManager = soundMan;
            //get explosion manager
            /*explosion manager stuff:
            0 - player bullets
            */
            explosionManager = exploMan;

            this.floorAssets = floorAssets;
            this.playerTextures = playerTextures;
            this.bulletTextures = bulletTextures;
            this.mapTextures = mapTextures;
            this.enemyTextures = enemyTextures;
            this.itemTextures = itemTextures;
            scoreFont = getScoreFont;
            statsFont = getStatFont;
            worldMan.generateWorld(currentLevel, graphics);
            floor = worldMan.getFloor();
            Enemy[] enemyGet = worldMan.getFloorEnemies();
            addEnemies(enemyGet);
            CheckEnemies();
            bossHealthBar[0] = new Rectangle((graphics.Viewport.Width / 2) - 200, graphics.Viewport.Height - 95, 400, 75);
            bossHealthBar[1] = new Rectangle(bossHealthBar[0].X + 5, bossHealthBar[0].Y + 3, bossHealthBar[0].Width - 10, bossHealthBar[0].Height - 6);
            Rectangle nextLevelRec = new Rectangle(0,0,0,0);
            updateFloorCollisions();
            itemList = worldMan.getItems();
            stats = new ScoreCount();
        }

        private void updateFloorCollisions()
        {
            floorCollisions = new List<Rectangle>();

            for (int i = 0; i < FLOOR_HEIGHT; i++)
            {
                for (int j = 0; j < FLOOR_WIDTH; j++)
                {
                    if (collisions.checkMove(floor[i, j]))
                    {
                        floorCollisions.Add(floorBounds[i, j]);
                    }
                }
            }
            
        }

        private void CheckEnemies()
        {
            if (enemyList == null)
            {
                return;
            }
            for (int i = 0; i < enemyList.Count; i++)
            {
                if (enemyList[i].Origin == new Vector2(0, 0) || enemyList[i].EnemyImage == null)
                {
                    var itemReset = new Enemy();
                    if (enemyList[i].EnemyType == 2)//bull boss
                    {
                       
                        Random rgen = new Random();
                        if(rgen.Next(1,10000001) == 1)
                        {
                            switch (rgen.Next(1, 5))
                            {
                                case 1:
                                    itemReset = (BullBoss)enemyList[i];
                                    itemReset.EnemyPicNum = 5;
                                    enemyList[i] = new BullBoss(worldMan.FloorBounds, enemyTextures[5, 0]);
                                    break;
                                case 2:
                                    itemReset = (BullBoss)enemyList[i];
                                    itemReset.EnemyPicNum = 6;
                                    enemyList[i] = new BullBoss(worldMan.FloorBounds, enemyTextures[6, 0]);
                                    break;
                                case 3:
                                    itemReset = (BullBoss)enemyList[i];
                                    itemReset.EnemyPicNum = 7;
                                    enemyList[i] = new BullBoss(worldMan.FloorBounds, enemyTextures[7, 0]);
                                    break;
                                case 4:
                                    itemReset = (BullBoss)enemyList[i];
                                    itemReset.EnemyPicNum = 8;
                                    enemyList[i] = new BullBoss(worldMan.FloorBounds, enemyTextures[8, 0]);
                                    break;
                                default:
                                    itemReset = (BullBoss)enemyList[i];
                                    itemReset.EnemyPicNum = 2;
                                    enemyList[i] = new BullBoss(worldMan.FloorBounds, enemyTextures[itemReset.EnemyType, 0]);
                                    break;
                            }
                        }
                        else
                        {
                            itemReset = (BullBoss)enemyList[i];

                            itemReset.EnemyPicNum = 2;
                             enemyList[i] = new BullBoss(worldMan.FloorBounds, enemyTextures[itemReset.EnemyType, 0]);
                           
                        }
                       
                    }
                    else if (enemyList[i].EnemyType == 3)//bounce boss
                    {
                        itemReset = (BounceBoss)enemyList[i];
                        itemReset.EnemyPicNum = 2;
                        enemyList[i] = new BounceBoss(worldMan.FloorBounds, enemyTextures[2, 0]);
                    }
                    else if (enemyList[i].EnemyType == 4)//speed boss
                    {
                        itemReset = (SpeedBoss)enemyList[i];
                        itemReset.EnemyPicNum = 2;
                        enemyList[i] = new SpeedBoss(worldMan.FloorBounds, enemyTextures[2, 0]);
                    }
                    else if (enemyList[i].EnemyType == 5)//flying rat
                    {
                        itemReset = enemyList[i];
                        itemReset.EnemyPicNum = 3;
                        //TODO: update enemy texture for flying rat
                        enemyList[i] = new FlyingRat(enemyTextures[3, 0]);
                    }
                    else if (enemyList[i].EnemyType == 6)//slow shooting boss
                    {
                        itemReset = (SlowShootBoss)enemyList[i];
                        itemReset.EnemyPicNum = 4;
                        //TODO: update enemy texture for flying rat
                        enemyList[i] = new SlowShootBoss(enemyTextures[4, 0]);
                    }
                    else if (enemyList[i].EnemyType == 7)//shooting boss
                    {
                        itemReset = (ShootBoss)enemyList[i];
                        itemReset.EnemyPicNum = 4;
                        //TODO: update enemy texture for flying rat
                        enemyList[i] = new ShootBoss(enemyTextures[4, 0]);
                    }
                    else
                    {
                        itemReset = enemyList[i];
                        if (enemyList[i].EnemyType == 0)
                        {
                            itemReset.EnemyPicNum = 0;
                        }
                        else if (enemyList[i].EnemyType == 1)
                        {
                            itemReset.EnemyPicNum = 1;
                        }
                        enemyList[i] = new Enemy(enemyTextures[itemReset.EnemyType, 0]);
                    }


                    enemyList[i].Health = itemReset.Health;
                    enemyList[i].Damage = itemReset.Damage;
                    enemyList[i].EnemyType = itemReset.EnemyType;
                    enemyList[i].Speed = itemReset.Speed;
                    enemyList[i].Pos = itemReset.Pos;
                    enemyList[i].EnemyPicNum = itemReset.EnemyPicNum;
                }
            }
            
        }

        private void checkCheat()
        {
            KeyboardState key = Keyboard.GetState();
            if (key.IsKeyDown(Keys.D2) && key.IsKeyDown(Keys.D4) && key.IsKeyDown(Keys.D6) && key.IsKeyDown(Keys.D8) && key.IsKeyDown(Keys.D1))
            {
                player.UpgradePoints++;
                cheatActive = true;
            }
        }

        // GAME UPDATE
        public void UpdateGame(MouseState mouse, GraphicsDevice graphics)
        {
            if(worldMan.isRoomClear())
            {
                roomTick = 0;
            }
            else if(roomTick > 0)
            {
                roomTick--;
            }
            if (bugTick < 500)
            {
                LevelBugCheck(graphics);
                bugTick++;
            }
            //player shoot
            if (mouse.LeftButton == ButtonState.Pressed && EnterGame == 0)
            {
                //shooting multiple bullets sounds terrible
                Bullet shot = player.Shoot();
                if (shot != null)
                {
                    playerBullets.Add(shot);

                    soundManager.playSound("water");
                }
            }
            else if (EnterGame != 0)
            {
                EnterGame--;
            }

            checkCheat();
            if (cheatActive)
            {
                stats.Score = 0;
            }
     
            //update player movement
            player.CheckAllowMove(floorBounds, floor, graphics.Viewport.Width, graphics.Viewport.Height, FLOOR_WIDTH, FLOOR_HEIGHT);
            if ((player.GetCurentFloor(floor, graphics.Viewport.Width, graphics.Viewport.Height, FLOOR_WIDTH, FLOOR_HEIGHT) == 4 || player.GetCurentFloor(floor, graphics.Viewport.Width, graphics.Viewport.Height, FLOOR_WIDTH, FLOOR_HEIGHT) == 21) && mouse.LeftButton == ButtonState.Released)
            {
                player.GainWater(worldMan.isRoomClear());
            }
            player.Update();

            if (player.dead)
            {
                noHealth = true;
            }

            //check if in boss room(music)
            if (worldMan.inBossRoom() && enemyList.Count > 0)
            {
                if (soundManager.currentSong != "bossMusic")
                {
                    soundManager.playSong("bossMusic");
                }
            }
            else
            {
                if (soundManager.currentSong != "bgm")
                {
                    soundManager.playSong("bgm");
                }
            }
            //check to see if you should go to the next level
            if (player.HitBox.Intersects(nextLevelRec))
            {
                TimeSpan floorTimeTaken = DateTime.Now - worldMan.floorTimeStart;
                double floorScore = (750 * worldMan.roomCount) / floorTimeTaken.TotalMinutes;
                stats.AddScore((int)(floorScore));

                isTransitioning = true;
                soundManager.playSound("elephant");
                currentLevel++;
                player.UpgradePoints += 2;
                worldMan.generateWorld(currentLevel, graphics);
                floor = worldMan.getFloor();
                Enemy[] enemyGet = worldMan.getFloorEnemies();
                addEnemies(enemyGet);
                player.Pos = new Vector2((graphics.Viewport.Width / 2), (graphics.Viewport.Height / 2));
                nextLevelRec = new Rectangle(0, 0, 0, 0);
                updateFloorCollisions();

            }

            //update player bullets
            List<Bullet> playerBulletsToRemove = new List<Bullet>();
            foreach (var item in playerBullets)
            {
                item.UpdateBullet();

                //see if each bullet hits an enemy
                foreach (var enemy in enemyList)
                {
                    bool hit = enemy.enemyHit(item);
                    if(hit == true)
                    {
                        soundManager.playSound("squeak");
                    }
                }

                bool alive = item.CheckLife(floor, graphics.Viewport.Width, graphics.Viewport.Height, FLOOR_WIDTH, FLOOR_HEIGHT);
                if (!alive)
                {
                    playerBulletsToRemove.Add(item);
                }
            }
            //remove any dead bullets
            foreach (var item in playerBulletsToRemove)
            {
                explosionManager.Add(new Vector2(item.Loc.X - 25, item.Loc.Y - 25), 0);
                playerBullets.Remove(item);
            }

            //update enemy list
            List<Enemy> enemiesToRemove = new List<Enemy>();
            foreach (var item in enemyList)
            {
                if (roomTick <= 0)
                {
                    item.UpdateEnemy(player, enemyList, floorCollisions);
                    item.UpdateAnimation();
                    player.playerHit(item.HitBox);
                
                
                    if (item.Dead)
                    {
                        enemiesToRemove.Add(item);
                    }
                }

                //check to see if enemy can shoot
                if (item.EnemyType == 5 || item.EnemyType == 6 || item.EnemyType == 7)
                {
                    if (item.EnemyType == 5)
                    {
                        FlyingRat flyingEnemy = (FlyingRat)item;
                        if (flyingEnemy.AbleToShoot)
                        {
                            Bullet bullet = flyingEnemy.Shoot();
                            enemyBullets.Add(bullet);
                        }
                    }
                    else if (item.EnemyType == 6)
                    {
                        SlowShootBoss flyingBoss = (SlowShootBoss)item;
                        if (flyingBoss.AbleToShoot)
                        {
                            Bullet bullet = flyingBoss.Shoot();
                            enemyBullets.Add(bullet);
                        }
                    }
                    else if (item.EnemyType == 7)
                    {
                        ShootBoss flyingBoss = (ShootBoss)item;
                        if (flyingBoss.AbleToShoot)
                        {
                            Bullet bullet = flyingBoss.Shoot();
                            enemyBullets.Add(bullet);
                        }
                    }

                }
                
                
            }
            //remove any dead enemies
            foreach (var item in enemiesToRemove)
            {
                enemyList.Remove(item);
                Item itemGet = itemMan.getItem(item.Pos);
                if (itemGet != null)
                {
                    worldMan.addItem(itemGet);
                    itemList = worldMan.getItems();
                }
                switch(item.EnemyType)
                {
                    case 0:
                        stats.AddScore(100);
                        break;
                    case 1:
                        stats.AddScore(150);
                        break;
                    case 2:
                        stats.AddScore(500);
                        break;
                    case 3:
                        stats.AddScore(650);
                        break;
                    case 4:
                        stats.AddScore(450);
                        break;
                    case 5:
                        stats.AddScore(150);
                        break;
                    case 6:
                        stats.AddScore(600);
                        break;
                    case 7:
                        stats.AddScore(750);
                        break;
                }

                if (item.EnemyType == 2 || item.EnemyType == 3 || item.EnemyType == 4 || item.EnemyType == 6 || item.EnemyType == 7)
                {
                    explosionManager.Add(new Vector2(item.Pos.X - 100, item.Pos.Y - 100), 2);
                }
                else
                {
                    explosionManager.Add(new Vector2(item.Pos.X - 32, item.Pos.Y - 32), 3);
                }
            }

            //update enemy bullets
            List<Bullet> enemyBulletsToRemove = new List<Bullet>();
            foreach (var item in enemyBullets)
            {
                item.UpdateBullet();

                //see if each bullet hits the player
                bool hit = (player.HitBox.Intersects(new Rectangle((int)item.Loc.X, (int)item.Loc.Y, 30, 30)));
                player.playerHit(new Rectangle((int)item.Loc.X, (int)item.Loc.Y, 30, 30));
                

                bool alive = item.CheckLife(floor, graphics.Viewport.Width, graphics.Viewport.Height, FLOOR_WIDTH, FLOOR_HEIGHT);
                if (!alive)
                {
                    enemyBulletsToRemove.Add(item);
                }
            }
            //remove any dead bullets
            foreach (var item in enemyBulletsToRemove)
            {
                explosionManager.Add(new Vector2(item.Loc.X - 25, item.Loc.Y - 25), 1);
                enemyBullets.Remove(item);
            }
            

            //see if all enemies are dead
            if (enemyList.Count <= 0 && !worldMan.isRoomClear())
            {
                roomTick = ROOM_DELAY;
                worldMan.ClearedRoom();
                floor = worldMan.getFloor();
                updateFloorCollisions();
            }

            //see if next level rec should be setup
            if (worldMan.worldPosNum() == 3 && worldMan.isRoomClear())
            {
                nextLevelRec = floorBounds[5, 10];
            }
            else
            {
                nextLevelRec = new Rectangle(0, 0, 0, 0);
            }

            bool gotItem = false;
            //check to see if an item is picked up
            foreach (var item in itemList)
            {
                if (player.HitBox.Intersects(item.Pos))
                {
                    item.function(player);
                    gotItem = true;
                }
            }
            if (gotItem)
            {
                worldMan.updateItemList();
                gotItem = false;
                itemList = worldMan.getItems();
            }

            //update player world pos
            if (player.Pos.X >= floorBounds[FLOOR_HEIGHT-1, FLOOR_WIDTH-1].Right)
            {
                worldMan.moveFloor(4);
            }
            else if (player.Pos.X <= graphics.Viewport.X)
            {
                worldMan.moveFloor(3);
            }

            if (player.Pos.Y >= floorBounds[FLOOR_HEIGHT-1, FLOOR_WIDTH-1].Bottom)
            {
                worldMan.moveFloor(2);
            }
            else if (player.Pos.Y <= graphics.Viewport.Y)
            {
                worldMan.moveFloor(1);
            }
            
            //update upgrade points
            if (player.UpgradePoints > 0)
            {
                stats.checkUpgrade(player);
            }

            //update world
            if (worldMan.MovedRooms || worldMan.isRoomClear())
            {

                roomTick = ROOM_DELAY;
                worldMan.updateMap();
                
                floor = worldMan.getFloor();
                updateFloorCollisions();
                itemList = worldMan.getItems();
                if (!worldMan.isRoomClear())
                {
                    Enemy[] enemyGet = worldMan.getFloorEnemies();
                    enemyList = new List<Enemy>();
                    if (enemyGet == null)
                    {
                        enemyGet = new Enemy[0];
                    }
                    addEnemies(enemyGet);
                    CheckEnemies();
                }

                //update player pos
                if (worldMan.MovedRooms)
                {
                    if (player.Pos.X >= floorBounds[FLOOR_HEIGHT - 1, FLOOR_WIDTH - 1].Right)
                    {
                        player.Pos.X = floorBounds[0, 0].Right + player.playerImage.Width/2;
                    }
                    else if (player.Pos.X <= graphics.Viewport.X)
                    {
                        player.Pos.X = floorBounds[0, 20].Left - player.playerImage.Width/2;
                    }

                    if (player.Pos.Y >= floorBounds[FLOOR_HEIGHT - 1, FLOOR_WIDTH - 1].Bottom)
                    {
                        player.Pos.Y = floorBounds[0, 0].Bottom + player.playerImage.Width/2;
                    }
                    else if (player.Pos.Y <= graphics.Viewport.Y)
                    {
                        player.Pos.Y = floorBounds[10, 0].Top - player.playerImage.Width/2;
                    }

                    worldMan.MovedRooms = false;
                    int playerBulletCount = playerBullets.Count();
                    for (int i = 0; i < playerBulletCount; i++)
                    {
                        playerBullets.RemoveAt(0);
                    }
                }
            }
            //update any explosion animations
            explosionManager.Update();

            //check for spikes
            if(player.GetCurentFloor(floor, graphics.Viewport.Width, graphics.Viewport.Height, FLOOR_WIDTH, FLOOR_HEIGHT) == 30)
            {
                player.playerHit();
            }
        }

        //GAME DRAW
        public void DrawGame(GraphicsDevice graphics, SpriteBatch spriteBatch)
        {
            //draw floor tiles
            int height = 0;
            int width = 0;
            Rectangle floorRec = new Rectangle(0, 0, graphics.Viewport.Width / FLOOR_WIDTH, graphics.Viewport.Height / FLOOR_HEIGHT);
            foreach (var item in floor)
            {
                if (firstRun)
                {
                    floorRec.X = (graphics.Viewport.Width / FLOOR_WIDTH) * width;
                    floorRec.Y = (graphics.Viewport.Height / FLOOR_HEIGHT) * height;
                    floorBounds[height, width] = floorRec;
                }
                spriteBatch.Draw(floorAssets[floor[height, width]], floorBounds[height, width], Color.White);

                width++;
                if (width == FLOOR_WIDTH)
                {
                    width = 0;
                    height++;
                }
            }
            if (firstRun)
            {
                firstRun = false;
                worldMan.getFloorBounds(floorBounds);
            }

            if (worldMan.inBossRoom() && enemyList.Count > 0)
            {
                spriteBatch.Draw(mapTextures[7], bossHealthBar[0], new Color(Color.White, 0.8f));
                int enemyType = enemyList[0].EnemyType;
                if (enemyType == 2 || enemyType == 3 || enemyType == 4 || enemyType == 6 || enemyType == 7)
                {
                    if (enemyType == 2)
                    {
                        BullBoss boss = (BullBoss)enemyList[0];
                        bossHealthBar[1].Width = (int)((bossHealthBar[0].Width - 10) * (boss.Health / boss.StartHealth));
                    }
                    else if (enemyType == 3)
                    {
                        BounceBoss boss = (BounceBoss)enemyList[0];
                        bossHealthBar[1].Width = (int)((bossHealthBar[0].Width - 10) * (boss.Health / boss.StartHealth));
                    }
                    else if (enemyType == 4)
                    {
                        SpeedBoss boss = (SpeedBoss)enemyList[0];
                        bossHealthBar[1].Width = (int)((bossHealthBar[0].Width - 10) * (boss.Health / boss.StartHealth));
                    }
                    else if (enemyType == 6)
                    {
                        SlowShootBoss boss = (SlowShootBoss)enemyList[0];
                        bossHealthBar[1].Width = (int)((bossHealthBar[0].Width - 10) * (boss.Health / boss.StartHealth));
                    }
                    else if (enemyType == 7)
                    {
                        ShootBoss boss = (ShootBoss)enemyList[0];
                        bossHealthBar[1].Width = (int)((bossHealthBar[0].Width - 10) * (boss.Health / boss.StartHealth));
                    }
                }

                spriteBatch.Draw(mapTextures[6], bossHealthBar[1], new Color(Color.White, 0.8f));
            }
            //draw next level tile
            spriteBatch.Draw(floorAssets[19], nextLevelRec, Color.White);
            
            //draw all items
            foreach (var item in itemList)
            {
                spriteBatch.Draw(itemTextures[item.Type], item.Pos, Color.White);
            }

            //draw all enemies
            foreach (var item in enemyList)
            {
                Color color = Color.White;
                if (roomTick % 2 != 0)
                {
                    color = new Color(Color.White, 0.5f);
                }
                spriteBatch.Draw(enemyTextures[item.EnemyPicNum, item.AnimationState], item.Pos, color: color, rotation: item.rotation, origin: item.Origin);
            }

            //draw all bullets
            foreach (var item in playerBullets)
            {
                spriteBatch.Draw(bulletTextures[0], item.Loc, null, Color.White, item.Rotation, item.Origin, 1.0f, SpriteEffects.None, 1);
            }

            //draw all enemy bullets
            foreach (var item in enemyBullets)
            {
                spriteBatch.Draw(bulletTextures[1], item.Loc, null, Color.White, item.Rotation, item.Origin, 1.0f, SpriteEffects.None, 1);
            }

            Color playerTint = Color.White;
            //draw player
            if (player.Iframes % 2 != 0)
            {
                playerTint = new Color(Color.White, 0.1f);
            }
            spriteBatch.Draw(playerTextures[player.AnimationState], player.Pos, null, playerTint, player.rotation, player.Origin, 1.0f, SpriteEffects.None, 1);

            //draw HUD
            for (int i = 0; i < player.HealthSlots; i++)//draw the health for the player
            {
                if (i < player.CurrentHealth)
                {
                    spriteBatch.Draw(playerTextures[5], new Vector2(75 + (50f * i), 10), Color.White);
                }
                else
                {
                    spriteBatch.Draw(playerTextures[6], new Vector2(75 + (50f * i), 10), Color.White);
                }
            }

            //draw water bar
            spriteBatch.Draw(playerTextures[3], new Rectangle(20, 10, playerTextures[3].Width, playerTextures[3].Height), Color.White);

            double percent = player.CurrentWater / player.MaxWater;

            int x = 18 + playerTextures[3].Width - playerTextures[4].Width;
            int y = 10 + playerTextures[3].Height - playerTextures[4].Height + (playerTextures[3].Height - (int)(playerTextures[4].Height * percent)) - 3;
            spriteBatch.Draw(playerTextures[4], new Rectangle(x, y, playerTextures[4].Width, (int)(playerTextures[4].Height * percent) - 1), Color.White);

            worldMan.drawMinimap(graphics, spriteBatch, mapTextures);

            stats.DrawScore(scoreFont, spriteBatch, graphics);

            stats.TimerCount(scoreFont, spriteBatch, graphics, currentLevel, Paused);
            if (player.UpgradePoints > 0)
            {
                stats.DrawStats(statsFont, player, spriteBatch, graphics);
            }

            //draw explosions
            explosionManager.Draw(spriteBatch);
        }

        public void loadPlayer(GraphicsDevice graphics)
        {
            System.Console.WriteLine("Loading Player");
            int xPos = (graphics.Viewport.Width / 2);
            int yPos = (graphics.Viewport.Height / 2);
            System.Console.WriteLine("Set-Up default X,Y");
            //setup default player attributes
            player = new Player(xPos, yPos, soundManager)
            {
                //TODO: reset defaults
                MaxWater = 10,
                CurrentWater = 10,
                HealthSlots = 5,
                CurrentHealth = 5,
                Damage = 5,
                Range = 45,
                Speed = 6,
                ShotSpeed = 45,
                BulletSpeed = 15,
                WaterGain = 25,
                playerImage = playerTextures[0]
            };
            System.Console.WriteLine("Created Player");
            //TODO: Attempt to load saved playdata from existing game (if there is one)
        }
        
        //this method just returns the player object health so that the game class can access the current health of the character in order to see if the game should changes to the gameover state
        public bool PlayerAlive()
        {
            if (player.CurrentHealth > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }


        private void addEnemies(Enemy[] enemyGet)
        {
            foreach (var item in enemyGet)
            {
                int healthAdd = 0;
                switch (item.EnemyType)
                {
                    case 0:
                        healthAdd = 5;
                        break;
                    case 1:
                        healthAdd = 7;
                        break;
                    case 2:
                        healthAdd = 50;
                        break;
                    case 3:
                        healthAdd = 75;
                        break;
                    case 4:
                        healthAdd = 25;
                        break;
                    case 5:
                        healthAdd = 5;
                        break;
                    case 6:
                        healthAdd = 35;
                        break;
                    case 7:
                        healthAdd = 50;
                        break;
                }

                item.Health += (healthAdd * (currentLevel - 1));
                
                enemyList.Add(item);
            }
        }

        public int GetScore()
        {
            return stats.Score;
        }

        public int GetLevel()
        {
            return currentLevel;
        }

        public string GetTime()
        {
            TimeSpan time = stats.TotalTime;
            string timeText = "";
            if (time.Hours < 10)
                timeText += "0" + time.Hours + ":";
            else
                timeText += time.Hours + ":";
            if (time.Minutes < 10)
                timeText += "0" + time.Minutes + ":";
            else
                timeText += time.Minutes + ":";
            if (time.Seconds < 10)
                timeText += "0" + time.Seconds;
            else
                timeText += time.Seconds;

            return timeText;
        }

        public void LevelBugCheck(GraphicsDevice graphics)
        {
            TimeSpan time = new TimeSpan(0, 0, 3);

            TimeSpan curTime = stats.TotalTime;

            if ((curTime < time) && (currentLevel > 1))
            {
                enemyList = new List<Enemy>();
                floor = new int[FLOOR_HEIGHT, FLOOR_WIDTH];
                Console.WriteLine("Level bug occured....\n!===Reseting game===!");
                worldMan = new WorldManager();
                //reset game because of bug
                worldMan.generateWorld(currentLevel, graphics);
                floor = worldMan.getFloor();
                Enemy[] enemyGet = worldMan.getFloorEnemies();
                addEnemies(enemyGet);
                CheckEnemies();
                Rectangle nextLevelRec = new Rectangle(0, 0, 0, 0);
                updateFloorCollisions();
                itemList = worldMan.getItems();
                stats = new ScoreCount();
                currentLevel = 1;
                player.UpgradePoints = 0;
            }

        }
    }
}
