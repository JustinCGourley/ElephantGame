﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System.IO;

namespace Elephant_Game
{
    class WorldManager
    {
        int[,] world = new int[11, 11];
        List<int[,]> worldFloors = new List<int[,]>();
        Random ran = new Random();

        bool[,] completedRoom = new bool[11,11];
        Vector2 currentPos;

        Rectangle minimap;
        Rectangle[,] minimapObjects = new Rectangle[11, 11];
        List<Enemy[]> enemyList = new List<Enemy[]>();
        RoomGenerator roomGen = new RoomGenerator();
        List<Rectangle> worldBounds = new List<Rectangle>();
        public bool MovedRooms { get; set; }
        private int numGenerated;
        int level = 0;
        public List<Rectangle> FloorBounds { get { return worldBounds; } }
        List<Item[]> itemList = new List<Item[]>();
        public DateTime floorTimeStart { get; set; }
        public int roomCount { get; set; }

        private void mapSetUp(GraphicsDevice graphics)
        {
            floorTimeStart = DateTime.Now;
            //create minimap rectangle
            int width = graphics.Viewport.Width;
            minimap = new Rectangle(width - (width/10) - 20, 20, width / 10, width / 10);

            //create minimap object's (all the floors) rectangles
            int objWidth = (width / 10) / 11;
            for (int i = 0; i < 11; i++)
            {
                for (int j = 0; j < 11; j++)
                {
                    minimapObjects[i, j] = new Rectangle(minimap.X + (objWidth * j) + 3, minimap.Y + (objWidth * i) + 3, objWidth, objWidth);
                }
            }
            
            //set the default player position
            currentPos = new Vector2(5, 5);

            roomGen.LoadRooms(graphics);
        }

        public void getFloorBounds(Rectangle[,] worldBounds)
        {
            for (int i = 0; i < 21; i++)
            {
                for (int j = 0; j < 11; j++)
                {
                    if (i == 0 || i == 20 || j == 0 || j == 10)
                    {
                        this.worldBounds.Add(worldBounds[j, i]);
                    }
                }
            }
        }

        public void checkWorld(int level, GraphicsDevice graphics)
        {
            int worldCount = 0;
            bool foundBossRoom = false, foundStartRoom = false;

            foreach (var item in world)
            {
                if (item != 0)
                {
                    worldCount++;
                    if (item == 2)
                    {
                        foundStartRoom = true;
                    }
                    if (item == 3)
                    {
                        foundBossRoom = true;
                    }
                }
            }

            double roomLoss = (numGenerated - worldCount) / numGenerated;


            bool bossRoomCheck = (world[5, 5] == 3);

            if (roomLoss > 0.3 || !foundBossRoom || !foundStartRoom || bossRoomCheck)
            {
                generateWorld(level, graphics);
                Console.WriteLine("Check Fail...");
            }

            Console.WriteLine("Check Pass");
            roomCount = numGenerated;
        }

        public void generateWorld(int level, GraphicsDevice graphics)
        {
            this.level = level;
            mapSetUp(graphics);

            worldFloors = new List<int[,]>();
            world = new int[11, 11];
            completedRoom = new bool[11, 11];
            enemyList = new List<Enemy[]>();
            itemList = new List<Item[]>();

            //generate rooms
            int ranNum = 5 + (ran.Next((int)((level * 1.5) + 10))) + (int)(level * 0.75);
            
            //max room count is 30
            if (ranNum > 50)
            {
                ranNum = 50;
            }
            numGenerated = ranNum;
            //set the default start world
            int[,] worldSet = {
                {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
                {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
                {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
                {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
                {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
                {0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0 },
                {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
                {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
                {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
                {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
                {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 }
            };
            //start generating the map
            int posX = 0;
            int posY = 0;
            
            do
            {
                //get a random spot on the map that is equal to 1 (or a open room)
                List<int[]> worldOnes = new List<int[]>();
                for (int a = 0; a < 11; a++)
                {
                    for (int b = 0; b < 11; b++)
                    {
                        if (worldSet[a, b] == 1)
                        {
                            int[] set = { a, b };
                            worldOnes.Add(set);
                        }
                    }
                }
                //get the randomly picked room
                int pick = ran.Next(worldOnes.Count);
                posX = worldOnes[pick][0];
                posY = worldOnes[pick][1];
                //get a random number of rooms that will be connected to this picked room
                int chance = ran.Next(4) + 1;
                if (chance > ranNum)
                {
                    chance = ranNum;
                }
                //start generating the new rooms
                for (int i = 0; i < chance; i++)
                {
                    //get the direction to generate room in (up, right, down, left)
                    int direction = ran.Next(4);
                    int worldNum = 1;
                    if (ranNum == 1)
                    {
                        worldNum = 3;
                    }
                        //generate room in random direction given
                        switch (direction)
                        {
                            case 0:
                                if (posY - 1 > 0 && worldSet[posX, posY - 1] != 1)
                                {
                                    worldSet[posX, posY - 1] = worldNum;
                                    ranNum -= 1;
                                }
                                break;
                            case 1:
                                if (posX + 1 > 0 && worldSet[posX + 1, posY] != 1)
                                {
                                    worldSet[posX + 1, posY] = worldNum;
                                    ranNum -= 1;
                                }
                                break;
                            case 2:
                                if (posY + 1 > 0 && worldSet[posX, posY + 1] != 1)
                                {
                                    worldSet[posX, posY + 1] = worldNum;
                                    ranNum -= 1;
                                }
                                break;
                            case 3:
                                if (posX - 1 > 0 && worldSet[posX - 1, posY] != 1)
                                {
                                    worldSet[posX - 1, posY] = worldNum;
                                    ranNum -= 1;
                                }
                                break;
                            default:
                                    //no room will be generated
                                break;
                        }
                }
                //setting current floor to [2] so it won't be picked again to generate more rooms
                worldSet[posX, posY] = 2;

            } while (ranNum > 0);

            //change all the 2's back to 1's
            for (int a = 0; a < 11; a++)
            {
                for (int b = 0; b < 11; b++)
                {
                    if (worldSet[a, b] == 2)
                    {
                        worldSet[a, b] = 1;
                    }
                    if (a == 5 && b == 5)
                    {
                        worldSet[a, b] = 2;
                    }
                }
            }

            world = worldSet;

            //generate the random floors for each non-empty room
            for (int a = 0; a < 11; a++)
            {
                for (int b = 0; b < 11; b++)
                {
                    int[,] floorGet;
                    Enemy[] enemiesGet;
                    if (world[b, a] == 1)
                    {
                        floorGet = roomGen.GetRoom();
                        enemiesGet = roomGen.GetEnemyForFloor(); 
                    }
                    else if (world[b, a] == 2)
                    {
                        floorGet = roomGen.DefaultFloor;
                        enemiesGet = new Enemy[0];
                    }
                    else if (world[b, a] == 3)
                    {
                        floorGet = roomGen.GetBossRoom();
                        enemiesGet = roomGen.GetBossEnemy(worldBounds);
                    }
                    else
                    {
                        floorGet = null;
                        enemiesGet = null;
                    }
                    itemList.Add(new Item[0]);
                    worldFloors.Add(floorGet);
                    enemyList.Add(enemiesGet);
                }
            }

            //make the first room be cleared
            completedRoom[5, 5] = true;
            //fixes world floors array
            int l = 0;
            int y = 0;
            int[,] test = new int[11, 11];
            foreach (var item in worldFloors)
            {
                if (item != null)
                {
                    test[l, y] = 1;
                }
                else
                {
                    test[l, y] = 0;
                }
                l++;
                if (l == 11)
                {
                    l = 0;
                    y++;
                }
            }
            test[5, 5] = 2;
            Console.WriteLine("Generated Room - Checking");
            checkWorld(level, graphics);

            
        }

        public void addItem(Item item)
        {

            Item[] newList = new Item[itemList[(int)(currentPos.X + (11 * currentPos.Y))].Length + 1];
            for (int i = 0; i < itemList[(int)(currentPos.X + (11 * currentPos.Y))].Length; i++)
            {
                Item addItem = itemList[(int)(currentPos.X + (11 * currentPos.Y))][i];
                
                newList[i] = addItem;
            }
            newList[newList.Length - 1] = item;

            itemList[(int)(currentPos.X + (11 * currentPos.Y))] = newList;
        }

        public void updateItemList()
        {
            List<Item> items = new List<Item>();
            List<Item> itemsToRemove = new List<Item>();

            foreach (var item in itemList[(int)(currentPos.X + (11 * currentPos.Y))])
            {
                items.Add(item);
                if (item.PickedUp)
                {
                    itemsToRemove.Add(item);
                }
            }
            
            foreach (var item in itemsToRemove)
            {
                items.Remove(item);
            }

            Item[] newItemList = new Item[items.Count];
            for (int i = 0; i < newItemList.Length; i++)
            {
                newItemList[i] = items[i];
            }

            if (newItemList == null)
            {
                newItemList = new Item[0];
            }

            itemList[(int)(currentPos.X + (11 * currentPos.Y))] = newItemList;
        }

        public Item[] getItems()
        {
            if (itemList[(int)(currentPos.X + (11 * currentPos.Y))] == null)
            {
                itemList[(int)(currentPos.X + (11 * currentPos.Y))] = new Item[0];
            }
            return itemList[(int)(currentPos.X + (11 * currentPos.Y))];
        }

        public int worldPosNum ()
        {
            return world[(int)currentPos.X, (int)currentPos.Y];
        }

        public int[,] getMap()
        {
            return world;
        }

        public int[,] getFloor()
        {
            return worldFloors[(int)(currentPos.X + (11 * currentPos.Y))];
        }

        public int[,] getFloor(int x, int y)
        {
            return worldFloors[x + (11 * y)];
        }

        public Enemy[] getFloorEnemies()
        {
            return enemyList[(int)(currentPos.X + (11 * currentPos.Y))];
        }

        public Enemy[] getFloorEnemies(int x, int y)
        {
            return enemyList[x + (11 * y)];
        }

        public bool isRoomClear()
        {
            return completedRoom[(int)(currentPos.X), (int)(currentPos.Y)];
        }

        public bool isRoomClear(int x, int y)
        {
            return completedRoom[x,y];
        }

        public void ClearedRoom()
        {
            int x = (int)(currentPos.X);
            int y = (int)(currentPos.Y);

            completedRoom[x, y] = true;
            
        }

        public bool inBossRoom()
        {
            bool inRoom = (world[(int)currentPos.X, (int)currentPos.Y] == 3);
            return inRoom;
        }

        public void updateMap()
        {
            int[] x = { 10, 10, 0, 20 };
            int[] y = { 0, 10, 5, 5 };

            const int walkTileIndex = 20;
            int posX = (int)(currentPos.X), posY = (int)(currentPos.Y);

            for (int i = 1; i <= 4; i++)
            {
                //top
                if (CanMove(i) && isRoomClear())
                {
                    worldFloors[posX + (11 * posY)][y[i - 1], x[i - 1]] = walkTileIndex;
                }
                else
                {
                    worldFloors[posX + (11 * posY)][y[i - 1], x[i - 1]] = 0;
                }
            }
            
        }

        public void moveFloor(int direction)
        {
            bool moved = false;
            //direction 1 - up, 2 - down, 3 - left, 4 - right
            int x = (int)(currentPos.X);
            int y = (int)(currentPos.Y);
            switch (direction)
            {
                case 1:
                    if (world[x - 1, y] != 0)
                    {
                        if (worldFloors[(x - 1) + (11 * y)] == null)
                        {
                            Console.WriteLine("Unable to move rooms as next room is null");
                        }
                        else
                        {
                            currentPos.X -= 1;
                            moved = true;
                        }
                    }
                    break;
                case 2:
                    if (world[x + 1, y] != 0)
                    {
                        if (worldFloors[(x + 1) + (11 * y)] == null)
                        {
                            Console.WriteLine("Unable to move rooms as next room is null");
                        }
                        else
                        {
                            currentPos.X += 1;
                            moved = true;
                        }
                    }
                    break;
                case 3:
                    if (world[x, y - 1] != 0)
                    {
                        if (worldFloors[x + (11 * (y-1))] == null)
                        {
                            Console.WriteLine("Unable to move rooms as next room is null");
                        }
                        else
                        {
                            currentPos.Y -= 1;
                            moved = true;
                        }
                    }
                    break;
                case 4:
                    if (world[x, y + 1] != 0)
                    {
                        if (worldFloors[x + (11 * (y + 1))] == null)
                        {
                            Console.WriteLine("Unable to move rooms as next room is null");
                        }
                        else
                        {
                            currentPos.Y += 1;
                            moved = true;
                        }
                    }
                    break;
                default:
                    Console.WriteLine("Invalid direction given, must be 1-4, you entered: " + direction);
                    break;
            }

            if (moved)
            {
                MovedRooms = true;
            }
        }

        public bool CanMove (int direction)
        {
            try
            {
                //direction 1 - up, 2 - down, 3 - left, 4 - right
                int x = (int)(currentPos.X);
                int y = (int)(currentPos.Y);
                switch (direction)
                {
                    case 1:
                        if (world[x - 1, y] != 0)
                        {
                            return true;
                        }
                        break;
                    case 2:
                        if (world[x + 1, y] != 0)
                        {
                            return true;
                        }
                        break;
                    case 3:
                        if (world[x, y - 1] != 0)
                        {
                            return true;
                        }
                        break;
                    case 4:
                        if (world[x, y + 1] != 0)
                        {
                            return true;
                        }
                        break;
                    default:
                        Console.WriteLine("Invalid direction given, must be 1-4, you entered: " + direction);
                        break;
                }

                return false;
            }
            catch
            {
                Console.WriteLine("Error occured while trying to check movement of rooms");
                return false;
            }
        }

        public void drawMinimap(GraphicsDevice graphics, SpriteBatch spriteBatch, Texture2D[] mapTextures)
        {
            spriteBatch.Draw(mapTextures[0], minimap, Color.White);
            
            Texture2D objState = mapTextures[1];
            for (int a = 0; a < 11; a++)
            {
                for (int b = 0; b < 11; b++)
                {
                    if (world[a, b] != 0)
                    {
                        if (a == currentPos.X && b == currentPos.Y)
                        {
                            objState = mapTextures[3];
                        }
                        else if (completedRoom[a, b])
                        {
                            if (world[a, b] == 3)
                                objState = mapTextures[5];
                            else
                                objState = mapTextures[1];
                        }
                        else
                        {
                            if (world[a, b] == 3)
                                objState = mapTextures[4];
                            else
                                objState = mapTextures[2];
                        }
                        
                        spriteBatch.Draw(objState, minimapObjects[a, b], Color.White);
                    }
                }
            }
            
        }

    }
}
