﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Elephant_Game
{
    class ShootBoss : Enemy
    {
        private int shootSpeed;
        private int shotTick;
        private int BulletSpeed { get; set; }
        private int Range { get; set; }
        public bool AbleToShoot { get; set; }
        public double StartHealth { get; set; }
        bool first = false;
        Random ran = new Random();
        private int attackType = 0;
        private int TickStop = 0;

        public ShootBoss()
        {
            Damage = 1;
            Range = 180;
            BulletSpeed = 15;
            shootSpeed = 60;
            shotTick = 0;
            EnemyPicNum = 4;
            this.EnemyImage = null;
            EnemyType = 7;
            Origin = new Vector2(0, 0);
            first = true;
        }

        public ShootBoss(Texture2D enemyImage)
        {
            Damage = 1;
            Range = 180;
            BulletSpeed = 15;
            shootSpeed = 60;
            shotTick = 0;
            this.EnemyImage = enemyImage;
            EnemyPicNum = 4;
            EnemyType = 7;
            Origin = new Vector2(EnemyImage.Width / 2, EnemyImage.Height / 2);
            first = true;
        }

        public override void UpdateEnemy(Player player, List<Enemy> enemies, List<Rectangle> floorCollisions)
        {
            if (first)
            {
                first = false;
                StartHealth = Health;
            }

            if (attackType == 0)
            {
                attackType = ran.Next(2) + 1;
                rotation = 0;
                TickStop = 0;
            }



            if (attackType == 1)
            {
                BulletSpeed = 10;
                shootSpeed = 0;
                ShootPlayer();
                rotation += 0.03f;
                if (rotation >= (Math.PI * 2))
                {
                    attackType = 0;
                }
            }

            else if (attackType == 2)
            {
                BulletSpeed = 15;
                ShootPlayer();
                double percentage = (Health / StartHealth);
                shootSpeed = (int)(60 * percentage) + 5;
                RotateTowardsEnemy(player);
                TickStop++;

                if (TickStop >= 300)
                {
                    attackType = 0;
                }
            }

            HitBox = new Rectangle((int)Pos.X - 75, (int)Pos.Y - 55, 150, 150);
            
        }

        private void ShootPlayer()
        {
            if (shotTick <= 0)
            {
                AbleToShoot = true;
                shotTick = shootSpeed;
            }
            if (!AbleToShoot)
            {
                shotTick--;
            }
        }

        public Bullet Shoot()
        {
            Bullet shot = null;

            double X = -(Math.Sin(rotation));
            double Y = Math.Cos(rotation);
            Vector2 direction = new Vector2((float)(X * BulletSpeed), (float)(Y * BulletSpeed));
            shot = new Bullet()
            {
                Lifespan = Range,
                Damage = this.Damage,
                Direction = direction,
                Loc = Pos,
                Rotation = (float)(rotation - (Math.PI * 1.5))
            };


            AbleToShoot = false;
            return shot;
        }


        private float getAngle(Player play)
        {
            Vector2 pos = new Vector2(Pos.X, Pos.Y);
            Vector2 playerpos = new Vector2(play.Pos.X, play.Pos.Y);
            Vector2 direction = playerpos - pos;

            float angle = (float)Math.Atan2(-direction.Y, -direction.X);
            angle += (float)(Math.PI * 0.5f);

            return angle;
        }
    }
}
