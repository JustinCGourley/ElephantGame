﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Elephant_Game
{
    class SpeedBoss : Enemy
    {
        private Vector2 movePos;
        private List<Rectangle> floorBounds;
        public double StartHealth { get; set; }
        bool first = true, move = false, movedIn;
        Random ran = new Random();

        public SpeedBoss(List<Rectangle> worldBounds)
        {
            floorBounds = worldBounds;
            EnemyType = 4;
            Origin = new Vector2(75, 100);
        }


        public SpeedBoss(List<Rectangle> worldBounds, Texture2D enemyImage)
        {
            EnemyImage = enemyImage;
            floorBounds = worldBounds;
            EnemyType = 4;
            Origin = new Vector2(75, 100);
        }

        public override void UpdateEnemy(Player player, List<Enemy> ignore1, List<Rectangle> ignore2)
        {
            if (first)
            {
                first = false;
                StartHealth = Health;
                setOutsidePos();
            }

            TrackPlayer(player);

            
            HitBox = new Rectangle((int)Pos.X - 75, (int)Pos.Y - 55, 150, 150);
        }

        private void setOutsidePos()
        {
            int spot = ran.Next(1, 4);
            float xPos = 0, yPos = 0;

            switch (spot)
            {
                case 1:
                    xPos = 750;
                    yPos = -200;
                    Speed = (int)(13 - ((Health/StartHealth) * 13)) + 7;
                    break;
                case 2:
                    xPos = 750;
                    yPos = 1100;
                    Speed = (int)(13 - ((Health / StartHealth) * 13)) + 7;
                    break;
                case 3:
                    xPos = -200;
                    yPos = 400;
                    Speed = (int)(15 - ((Health / StartHealth) * 15)) + 10;
                    break;
                case 4:
                    xPos = 1800;
                    yPos = 400;
                    Speed = (int)(15 - ((Health / StartHealth) * 15)) + 10;
                    break;
            }

            Pos.X = xPos;
            Pos.Y = yPos;
            move = true;
            movedIn = false;
        }

        public override void RotateTowardsEnemy(Player play)
        {
            //Vector2 myPos = new Vector2(Pos.X, Pos.Y);
            //Vector2 enemyPos = new Vector2(play.Pos.X, play.Pos.Y);
            float xDis = play.Pos.X - Pos.X;
            float yDis = play.Pos.Y - Pos.Y;
            float angle = (float)Math.Atan2(yDis, xDis);
            angle -= (float)(Math.PI * 0.5);
            
            rotation = angle;

        }

        public override void TrackPlayer(Player player)
        {

            if ((Pos.X >= 1800 || Pos.X < -200 || Pos.Y >= 1100 || Pos.Y <= -200) && movedIn)
            {
                setOutsidePos();
                return;
            }
            if (!movedIn)
            {
                if ((Pos.X > 100 && Pos.X < 1500) && (Pos.Y > 100 && Pos.Y < 800))
                {
                    movedIn = true;
                }
            }
            if (move)
            {
                move = false;
                float angle = getAngle(player);
                double X = -(Math.Sin(angle));
                double Y = Math.Cos(angle);
                Vector2 direction = new Vector2((float)(X * Speed), (float)(Y * Speed));
                movePos = direction;
                RotateTowardsEnemy(player);
            }

            Pos.X += movePos.X;
            Pos.Y += movePos.Y;
        }

        private bool hitWorld()
        {
            bool hit = false;

            foreach (var item in floorBounds)
            {
                if (HitBox.Intersects(item))
                {
                    if (item.X < Pos.X)
                    {
                        Pos.X += 2;
                    }
                    else if (item.X > Pos.X)
                    {
                        Pos.X -= 2;
                    }
                    if (item.Y < Pos.Y)
                    {
                        Pos.Y += 2;
                    }
                    else if (item.Y > Pos.Y)
                    {
                        Pos.Y -= 2;
                    }
                    hit = true;
                }
            }

            return hit;
        }

        private float getAngle(Player player)
        {
            Vector2 bossPos = new Vector2(Pos.X + 75, Pos.Y + 65);
            Vector2 playerPos = new Vector2(player.Pos.X, player.Pos.Y);
            Vector2 direction = playerPos - bossPos;
            float angle = (float)Math.Atan2(-direction.Y, -direction.X);
            angle += (float)(Math.PI * 0.5f);
            return angle;
        }
    }
}
