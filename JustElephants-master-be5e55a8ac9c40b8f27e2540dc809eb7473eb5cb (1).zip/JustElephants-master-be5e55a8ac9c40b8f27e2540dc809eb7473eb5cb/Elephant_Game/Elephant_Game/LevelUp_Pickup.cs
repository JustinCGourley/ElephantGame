﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Elephant_Game
{
    class LevelUp_Pickup : Item
    {
        public LevelUp_Pickup(Rectangle pos) : base (pos, 1)
        {
        }

        public override void function(Player player)
        {
            player.UpgradePoints++;
            PickedUp = true;
        }
    }
}
