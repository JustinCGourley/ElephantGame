﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework.Input;
using System.Threading.Tasks;

namespace Elephant_Game
{
    class BullBoss : Enemy
    {
        private int moveTick = 115;
        private Vector2 movePos;
        private List<Rectangle> floorBounds;
        public double StartHealth { get; set; }
        private bool tracking = false;
        bool first = true;

        public BullBoss(List<Rectangle> worldBounds)
        {
            floorBounds = worldBounds;
            EnemyType = 2;
            Origin = new Vector2(75, 100);
        }


        public BullBoss(List<Rectangle> worldBounds, Texture2D enemyImage)
        {
            EnemyImage = enemyImage;
            floorBounds = worldBounds;
            EnemyType = 2;
            Origin = new Vector2(75, 100);
        }

        public override void UpdateEnemy(Player player, List<Enemy> ignore1, List<Rectangle> ignore2)
        {
            if (first)
            {
                first = false;
                StartHealth = Health;
            }
            TrackPlayer(player);
            if (moveTick >= 60)
            {
                RotateTowardsEnemy(player);
            }
            else
            {
                tracking = false;
            }
            HitBox = new Rectangle((int)Pos.X - 75, (int)Pos.Y - 55, 150, 150);
        }

        public override void RotateTowardsEnemy(Player play)
        {
            //Vector2 myPos = new Vector2(Pos.X, Pos.Y);
            //Vector2 enemyPos = new Vector2(play.Pos.X, play.Pos.Y);
            float xDis = play.Pos.X - Pos.X;
            float yDis = play.Pos.Y - Pos.Y;
            float angle = (float)Math.Atan2(yDis, xDis);
            angle -= (float)(Math.PI * 0.5);

            float max = (angle + 0.2f);
            float min = (angle - 0.2f);

            if ((rotation <= max && rotation >= min) || tracking)
            {
                tracking = true;
                rotation = angle;
            }
            else if (!tracking)
            {
                float angleToAdd = (angle < rotation) ? -0.15f : 0.15f;
                rotation += angleToAdd;
            }

        }

        public override void TrackPlayer(Player player)
        {
            if (HitBox.Intersects(player.HitBox))
            {
                moveTick = 50;
                return;
            }
            if (hitWorld())
            {
                moveTick = 50;
                return;
            }
            if (moveTick >= 50)
            {
                if (moveTick >= (Health + 100))
                {
                    moveTick = 0;
                    float angle = getAngle(player);
                    double X = -(Math.Sin(angle));
                    double Y = Math.Cos(angle);
                    Vector2 direction = new Vector2((float)(X * Speed), (float)(Y * Speed));
                    movePos = direction;
                }
            }
            else if (moveTick < 50)
            {
                Pos.X += movePos.X;
                Pos.Y += movePos.Y;
            }

            moveTick++;
        }

        private bool hitWorld()
        {
            bool hit = false;

            foreach (var item in floorBounds)
            {
                if (HitBox.Intersects(item))
                {
                    if (item.X < Pos.X)
                    {
                        Pos.X += 2;
                    }
                    else if (item.X > Pos.X)
                    {
                        Pos.X -= 2;
                    }
                    if (item.Y < Pos.Y)
                    {
                        Pos.Y += 2;
                    }
                    else if (item.Y > Pos.Y)
                    {
                        Pos.Y -= 2;
                    }
                    hit = true;
                }
            }

            return hit;
        }

        private float getAngle(Player player)
        {
            Vector2 bossPos = new Vector2(Pos.X + 75, Pos.Y + 65);
            Vector2 playerPos = new Vector2(player.Pos.X, player.Pos.Y);
            Vector2 direction = playerPos - bossPos;
            float angle = (float)Math.Atan2(-direction.Y, -direction.X);
            angle += (float)(Math.PI * 0.5f);
            return angle;
        }
    }
}
