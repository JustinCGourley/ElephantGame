﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Elephant_Game
{
    class SlowShootBoss : Enemy
    {
        private int shootSpeed;
        private int shotTick;
        private int BulletSpeed { get; set; }
        private int Range { get; set; }
        public bool AbleToShoot { get; set; }
        public double StartHealth { get; set; }
        bool first = false;

        public SlowShootBoss()
        {
            Damage = 1;
            Range = 180;
            BulletSpeed = 15;
            shootSpeed = 60;
            shotTick = 0;
            EnemyPicNum = 4;
            this.EnemyImage = null;
            EnemyType = 6;
            Origin = new Vector2(0,0);
            first = true;
        }

        public SlowShootBoss(Texture2D enemyImage)
        {
            Damage = 1;
            Range = 180;
            BulletSpeed = 15;
            shootSpeed = 60;
            shotTick = 0;
            this.EnemyImage = enemyImage;
            EnemyPicNum = 4;
            EnemyType = 6;
            Origin = new Vector2(EnemyImage.Width / 2, EnemyImage.Height / 2);
            first = true;
        }

        public override void UpdateEnemy(Player player, List<Enemy> enemies, List<Rectangle> floorCollisions)
        {
            if (first)
            {
                first = false;
                StartHealth = Health;
            }
            // always face player, move towards player
            RotateTowardsEnemy(player);

            Vector2 vec = Pos - player.Pos;

            if (vec.Length() >= 600)
            {
                TrackPlayer(player);
                AbleToShoot = false;
            }
            else
            {
                ShootPlayer(player);
            }

            HitBox = new Rectangle((int)Pos.X - 75, (int)Pos.Y - 55, 150, 150);

            checkIntersection(enemies);
            checkWorldMovement(floorCollisions);

            double percentage = (Health / StartHealth);
            shootSpeed = (int)(60 * percentage) + 5;

        }

        private void ShootPlayer(Player player)
        {
            float myAngle = getAngle(player);

            if (shotTick <= 0)
            {
                AbleToShoot = true;
                shotTick = shootSpeed;
            }
            if (!AbleToShoot)
            {
                shotTick--;
            }
        }

        public Bullet Shoot()
        {
            Bullet shot = null;

            double X = -(Math.Sin(rotation));
            double Y = Math.Cos(rotation);
            Vector2 direction = new Vector2((float)(X * BulletSpeed), (float)(Y * BulletSpeed));
            shot = new Bullet()
            {
                Lifespan = Range,
                Damage = this.Damage,
                Direction = direction,
                Loc = Pos,
                Rotation = (float)(rotation - (Math.PI * 1.5))
            };


            AbleToShoot = false;
            return shot;
        }


        private float getAngle(Player play)
        {
            Vector2 pos = new Vector2(Pos.X, Pos.Y);
            Vector2 playerpos = new Vector2(play.Pos.X, play.Pos.Y);
            Vector2 direction = playerpos - pos;

            float angle = (float)Math.Atan2(-direction.Y, -direction.X);
            angle += (float)(Math.PI * 0.5f);

            return angle;
        }
    }
}
