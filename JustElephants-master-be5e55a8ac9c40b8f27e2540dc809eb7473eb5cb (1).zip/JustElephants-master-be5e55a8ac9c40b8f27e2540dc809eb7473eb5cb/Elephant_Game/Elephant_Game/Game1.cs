﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Media;
using System.Threading;

namespace Elephant_Game
{
    //gamestate 
    enum GameState
    {
        MAIN_MENU,
        GAME,
        DEATH,
        LEVEL_EDIT,
        PAUSE
    }


    /// <summary>
    /// This is the main type for your game.
    /// </summary>
    public class Game1 : Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;
        GameState currentstate;




        //---global var's---
        bool holdKey = false;
        bool paused = false;
        //game stuff
        GameLogic game = new GameLogic();
        //editor stuff
        bool editorActive = false;
        LevelEditor editor = new LevelEditor();

        //---assets---
        //player assets
        Texture2D playerImage_Still;
        Texture2D playerShot;
        Texture2D[] playerTextures, bulletTextures, mapTextures, itemTextures;
        Texture2D[,] enemyTextures;
        //enemy assets
        Texture2D smallMouse_Still;
        //floor assets
        Texture2D[] floorAssets;
        //editor assets
        Texture2D[] editorAssets;
        //mouse reticle
        Texture2D reticle, reticle_edit;
        //Main Menu asset
        Texture2D bg, btn, ded, trans;
        float transChange;
        //HUD
        Texture2D[] WaterBar;
        Texture2D[] Health;

        SpriteFont font, bfont, mfont, scoreFont, statFont;
        //pause
        Texture2D pz;
        int transTick = 0;
        bool isreveresed = false;
        bool mouseDown = false;

        KeyboardState prev;
        SoundManager soundManager;
        ExplosionManager explosionManager;
        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            graphics.PreferredBackBufferHeight = 900;
            graphics.PreferredBackBufferWidth = 1600;
        }

        protected override void Initialize()
        {
            currentstate = GameState.MAIN_MENU;
            transChange = 0.0f;
            isreveresed = false;
            transTick = 0;
            System.Console.WriteLine("Finished Initializing");
            base.Initialize();
        }

        protected override void LoadContent()
        {
            spriteBatch = new SpriteBatch(GraphicsDevice);

            //asset loading             

            //mouse stuff
            reticle = Content.Load<Texture2D>("reticle2");
            reticle_edit = Content.Load<Texture2D>("levelEditReticle");

            floorAssets = new Texture2D[32];
            //load floor assets
            floorAssets[0] = Content.Load<Texture2D>("Tiles/wallTile"); // top wall
            floorAssets[1] = Content.Load<Texture2D>("Tiles/wall_bottom"); // bottom wall
            floorAssets[2] = Content.Load<Texture2D>("Tiles/wall_left"); // left wall
            floorAssets[3] = Content.Load<Texture2D>("Tiles/wall_right"); // right wall

            floorAssets[4] = Content.Load<Texture2D>("Tiles/groundtilewithpuddle"); //puddle tile
            floorAssets[5] = Content.Load<Texture2D>("Tiles/boulder"); // boulder tile
            floorAssets[6] = Content.Load<Texture2D>("Tiles/rocks");
            floorAssets[7] = Content.Load<Texture2D>("Tiles/sand_rocks");
            floorAssets[8] = Content.Load<Texture2D>("Tiles/rock");

            //tile with sand edge (TL - top left, BR - bottom right)
            floorAssets[9] = Content.Load<Texture2D>("Tiles/orange_sandCorner_TL");
            floorAssets[10] = Content.Load<Texture2D>("Tiles/orange_sandCorner_TR");
            floorAssets[11] = Content.Load<Texture2D>("Tiles/orange_sandCorner_BL");
            floorAssets[12] = Content.Load<Texture2D>("Tiles/orange_sandCorner_BR");
            //sand tile with normal tile edge (TL - top left, BR - bottom right)
            floorAssets[13] = Content.Load<Texture2D>("Tiles/sandCorner_TL");
            floorAssets[14] = Content.Load<Texture2D>("Tiles/sandCorner_TR");
            floorAssets[15] = Content.Load<Texture2D>("Tiles/sandCorner_BL");
            floorAssets[16] = Content.Load<Texture2D>("Tiles/sandCorner_BR");
            floorAssets[17] = Content.Load<Texture2D>("Tiles/sand");
            floorAssets[18] = Content.Load<Texture2D>("Tiles/plainOrangeSand");
            floorAssets[19] = Content.Load<Texture2D>("Tiles/nextLevelTile");
            floorAssets[20] = Content.Load<Texture2D>("Tiles/walkTile");
            floorAssets[21] = Content.Load<Texture2D>("Tiles/waterStonneTile");
            floorAssets[22] = Content.Load<Texture2D>("Tiles/standardStoneFloor");
            floorAssets[23] = Content.Load<Texture2D>("Tiles/stoneBottomLeft");
            floorAssets[24] = Content.Load<Texture2D>("Tiles/stoneBottomMiddleRug");
            floorAssets[25] = Content.Load<Texture2D>("Tiles/stoneBottomRightRug");
            floorAssets[26] = Content.Load<Texture2D>("Tiles/stoneTopLeft");
            floorAssets[27] = Content.Load<Texture2D>("Tiles/stoneTopMiddleRug");
            floorAssets[28] = Content.Load<Texture2D>("Tiles/stoneTopRightRug");
            floorAssets[29] = Content.Load<Texture2D>("Tiles/stoneObsticle");
            floorAssets[30] = Content.Load<Texture2D>("Tiles/spikepit");
            floorAssets[31] = Content.Load<Texture2D>("Tiles/emptyPit");

            mapTextures = new Texture2D[8];
            //load minimap sprites
            mapTextures[0] = Content.Load<Texture2D>("Sprites/Minimap/MinimapBackground");
            mapTextures[1] = Content.Load<Texture2D>("Sprites/Minimap/MinimapRoom_Unknown");
            mapTextures[2] = Content.Load<Texture2D>("Sprites/Minimap/MinimapRoom_Cleared");
            mapTextures[3] = Content.Load<Texture2D>("Sprites/Minimap/MinimapRoom_Current");
            mapTextures[4] = Content.Load<Texture2D>("Sprites/Minimap/MinimapRoom_Boss");
            mapTextures[5] = Content.Load<Texture2D>("Sprites/Minimap/MinimapRoom_BossCompleted");
            mapTextures[6] = Content.Load<Texture2D>("Sprites/Enemies/healthBar");
            mapTextures[7] = Content.Load<Texture2D>("Sprites/Enemies/healthBarBackground");

            //load other textures
            bulletTextures = new Texture2D[2];
            bulletTextures[0] = Content.Load<Texture2D>("Sprites/Player/water projectile");
            bulletTextures[1] = Content.Load<Texture2D>("Sprites/Enemies/enemyBullet");

            //player textures
            playerTextures = new Texture2D[7];
            playerTextures[0] = Content.Load<Texture2D>("Sprites/Player/elephantSprite_0");
            playerTextures[1] = Content.Load<Texture2D>("Sprites/Player/elephantSprite_1");
            playerTextures[2] = Content.Load<Texture2D>("Sprites/Player/elephantSprite_2");

            //hud textures
            playerTextures[3] = Content.Load<Texture2D>("Sprites/Player/WaterBarBack");
            playerTextures[4] = Content.Load<Texture2D>("Sprites/Player/WaterBar");
            playerTextures[5] = Content.Load<Texture2D>("Sprites/Player/Peanut");
            playerTextures[6] = Content.Load<Texture2D>("Sprites/Player/EmptyPeanut");
            trans = Content.Load<Texture2D>("transparent");

            //item textures
            itemTextures = new Texture2D[3];
            itemTextures[0] = Content.Load<Texture2D>("Sprites/Items/peanut");
            itemTextures[1] = Content.Load<Texture2D>("Sprites/Items/levelUp");
            itemTextures[2] = Content.Load<Texture2D>("Sprites/Items/invincibleStar");

            //TODO Update names to be more legible 
            bg = Content.Load<Texture2D>("elephantbackground");
            pz = Content.Load<Texture2D>("pause");
            btn = Content.Load<Texture2D>("button");
            ded = Content.Load<Texture2D>("dead");


            editorAssets = new Texture2D[3];
            editorAssets[0] = Content.Load<Texture2D>("Tiles/editorTile");
            editorAssets[1] = Content.Load<Texture2D>("Tiles/editorTile-Select");
            editorAssets[2] = Content.Load<Texture2D>("removeEnemy");

            enemyTextures = new Texture2D[9, 3];
            enemyTextures[0, 0] = Content.Load<Texture2D>("Sprites/Enemies/finalmouse_0");
            enemyTextures[0, 1] = Content.Load<Texture2D>("Sprites/Enemies/finalmouse_1");
            enemyTextures[0, 2] = Content.Load<Texture2D>("Sprites/Enemies/finalmouse_2");
            enemyTextures[1, 0] = Content.Load<Texture2D>("Sprites/Enemies/finalRat_0");
            enemyTextures[1, 1] = Content.Load<Texture2D>("Sprites/Enemies/finalRat_1");
            enemyTextures[1, 2] = Content.Load<Texture2D>("Sprites/Enemies/finalRat_2");
            enemyTextures[2, 0] = Content.Load<Texture2D>("Sprites/Enemies/bossrat_0");
            enemyTextures[2, 1] = Content.Load<Texture2D>("Sprites/Enemies/bossrat_1");
            enemyTextures[2, 2] = Content.Load<Texture2D>("Sprites/Enemies/bossrat_2");
            enemyTextures[3, 0] = Content.Load<Texture2D>("Sprites/Enemies/flyingRat_0");
            enemyTextures[3, 1] = Content.Load<Texture2D>("Sprites/Enemies/flyingRat_1");
            enemyTextures[3, 2] = Content.Load<Texture2D>("Sprites/Enemies/flyingRat_2");
            enemyTextures[4, 0] = Content.Load<Texture2D>("Sprites/Enemies/flyingBoss_0");
            enemyTextures[4, 1] = Content.Load<Texture2D>("Sprites/Enemies/flyingBoss_1");
            enemyTextures[4, 2] = Content.Load<Texture2D>("Sprites/Enemies/flyingBoss_2");
            enemyTextures[5, 0] = Content.Load<Texture2D>("Sprites/Enemies/camHeadInvert");
            enemyTextures[5, 1] = Content.Load<Texture2D>("Sprites/Enemies/camHead");
            enemyTextures[5, 2] = Content.Load<Texture2D>("Sprites/Enemies/camHead");
            enemyTextures[6, 0] = Content.Load<Texture2D>("Sprites/Enemies/nickHeadInvert");
            enemyTextures[6, 1] = Content.Load<Texture2D>("Sprites/Enemies/nickHead");
            enemyTextures[6, 2] = Content.Load<Texture2D>("Sprites/Enemies/nickHead");
            enemyTextures[7, 0] = Content.Load<Texture2D>("Sprites/Enemies/justinGHeadInvert");
            enemyTextures[7, 1] = Content.Load<Texture2D>("Sprites/Enemies/justinGHead");
            enemyTextures[7, 2] = Content.Load<Texture2D>("Sprites/Enemies/justinGHead");
            enemyTextures[8, 0] = Content.Load<Texture2D>("Sprites/Enemies/justinAHeadInvert");
            enemyTextures[8, 1] = Content.Load<Texture2D>("Sprites/Enemies/justinAHead");
            enemyTextures[8, 2] = Content.Load<Texture2D>("Sprites/Enemies/justinAHead");


            //load fonts
            font = Content.Load<SpriteFont>("font");
            mfont = Content.Load<SpriteFont>("menuFont");
            bfont = Content.Load<SpriteFont>("buttonFont");
            scoreFont = Content.Load<SpriteFont>("ScoreFont");
            statFont = Content.Load<SpriteFont>("StatFont");


            //sounds
            SoundEffect elephant = Content.Load<SoundEffect>("Sounds/Elephant");
            SoundEffect squeak = Content.Load<SoundEffect>("Sounds/mouse squeak");
            SoundEffect ugh = Content.Load<SoundEffect>("Sounds/ugh");
            SoundEffect water = Content.Load<SoundEffect>("Sounds/Water Splash");
            SoundEffect[] effects = new SoundEffect[4];
            //add effects below
            effects[0] = elephant;
            effects[1] = squeak;
            effects[2] = ugh;
            effects[3] = water;

            string[] effectNames = 
            {"elephant", "squeak", "ugh","water" 
            };

            Song[] songList = new Song[2];
            //add songs here
            songList[0] = Content.Load<Song>("Sounds/BackgroundMusic");
            songList[1] = Content.Load<Song>("Sounds/bossmusic");
            string[] songNames =
            {
                //add song names here
                "bgm",
                "bossMusic"
            };

            soundManager = new SoundManager(effects, effectNames, songList, songNames);

            //add all the states for the explosion here 
            //(each type of explosion is differentiated by the first number (ex. 0 is for the player bullet) and the second number is for each state in the animation)
            Texture2D[,] explosions = new Texture2D[4, 3];
            explosions[0, 0] = Content.Load<Texture2D>("Sprites/Explosions/explosion_0");
            explosions[0, 1] = Content.Load<Texture2D>("Sprites/Explosions/explosion_1");
            explosions[0, 2] = Content.Load<Texture2D>("Sprites/Explosions/explosion_2");
            explosions[1, 0] = Content.Load<Texture2D>("Sprites/Explosions/enemy_explosion_0");
            explosions[1, 1] = Content.Load<Texture2D>("Sprites/Explosions/enemy_explosion_1");
            explosions[1, 2] = Content.Load<Texture2D>("Sprites/Explosions/enemy_explosion_2");
            explosions[2, 0] = Content.Load<Texture2D>("Sprites/Explosions/boss_explosion_0");
            explosions[2, 1] = Content.Load<Texture2D>("Sprites/Explosions/boss_explosion_1");
            explosions[2, 2] = Content.Load<Texture2D>("Sprites/Explosions/boss_explosion_2");
            explosions[3, 0] = Content.Load<Texture2D>("Sprites/Explosions/rat_explosion_0");
            explosions[3, 1] = Content.Load<Texture2D>("Sprites/Explosions/rat_explosion_1");
            explosions[3, 2] = Content.Load<Texture2D>("Sprites/Explosions/rat_explosion_2");

            //this array coordinated with the explosion textures, each value represents an explosion type, and defines the number of animation states in said type
            int[] explosionCounts =
            {
                3,3,3,3
            };

            //same as the count except this defines how fast the animation will play (will change frame every 'x' amount of ticks)
            int[] explosionPlaybackSpeed =
            {
                4,4,4,4
            };

            explosionManager = new ExplosionManager(explosions, explosionCounts, explosionPlaybackSpeed);

            game.initialRun = true;
            //setup game
            game.setUp(GraphicsDevice, floorAssets, playerTextures, bulletTextures, mapTextures, enemyTextures, scoreFont, statFont, soundManager, itemTextures, explosionManager);
            //load player
            game.loadPlayer(GraphicsDevice);

            

            System.Console.WriteLine("Finished Loading Content");
        }

        protected override void UnloadContent()
        {
        }


        //menu stuff
        bool overStart = false;
        Rectangle startbox = new Rectangle(350, 700, 250, 75);
        bool overLevelEdit = false;
        Rectangle leveleditbox = new Rectangle(825, 700, 400, 75);
        bool overSaveQuit = false;
        Rectangle SaveQuitbox = new Rectangle(540, 700, 550, 75);
        bool overReturntoMenu = false;
        Rectangle returntoMenubox = new Rectangle(540, 500, 550, 75);
        bool overDedmenu = false;
        Rectangle dedMenuBox = new Rectangle(540, 700, 550, 75);
        bool overQuit = false;
        Rectangle quitMainBox = new Rectangle(1325,800,250,75);
        bool overPauseQuit = false;
        Rectangle pauseQuitBox = new Rectangle(540, 600, 550, 75);
        bool overLevelMain = false;
        Rectangle levelMainBox = new Rectangle(1100, 785, 450, 75);

        public void UpdateMainMenu()
        {
            MouseState mouse = Mouse.GetState();

            checkStart(mouse);
            checkLevelEdit(mouse);
            checkQuit(mouse);
        }

        public void UpdatePauseMenu()
        {
            MouseState mouse = Mouse.GetState();

            checkSaveQuit(mouse);
            checkReturntoMenu(mouse);
            checkQuitGame(mouse);

        }

        public void UpdateDeath()
        {
            MouseState mouse = Mouse.GetState();
            checkDedMenu(mouse);

        }
        public void UpdateLevelMain()
        {
            MouseState mouse = Mouse.GetState();
            checkLevelMain(mouse);
        }


        private void checkStart(MouseState mouse)
        {
            Rectangle mouseRec = new Rectangle(mouse.X, mouse.Y, 1, 1);
            if (startbox.Intersects(mouseRec))
            {
                overStart = true;
                if (mouse.LeftButton == ButtonState.Pressed && !mouseDown)
                {
                    //do clicked button stuff
                    currentstate = GameState.GAME;
                    game = new GameLogic();
                    game.initialRun = true;
                    game.setUp(GraphicsDevice, floorAssets, playerTextures, bulletTextures, mapTextures, enemyTextures, scoreFont, statFont, soundManager, itemTextures, explosionManager);
                    //load player
                    game.loadPlayer(GraphicsDevice);
                }
            }
            else
            {
                overStart = false;
            }
        }

        public void checkDedMenu(MouseState mouse)
        {
            Rectangle mouseRec = new Rectangle(mouse.X, mouse.Y, 1, 1);
            if (dedMenuBox.Intersects(mouseRec))
            {
                overDedmenu = true;
                if (mouse.LeftButton == ButtonState.Pressed && !mouseDown)
                {
                    //do clicked button stuff
                   // game.noHealth = false; //if this isnt done, the current state switches back to the main menu, it sees there is no health and then switches back to the death screen before the main menu is even drawn
                    currentstate = GameState.MAIN_MENU;
                    Console.WriteLine(currentstate);
                
                }
            }
            else
            {
                overDedmenu = false;
            }
        }


        private void checkLevelEdit(MouseState mouse)
        {
            Rectangle mouseRec = new Rectangle(mouse.X, mouse.Y, 1, 1);
            if (leveleditbox.Intersects(mouseRec))
            {
                overLevelEdit = true;
                if (mouse.LeftButton == ButtonState.Pressed && !mouseDown)
                {
                    //do clicked button stuff
                    editorActive = !editorActive;
                    holdKey = true;
                    game.initialRun = true;
                    editor.setUp(game.floor, game.floorBounds, floorAssets, editorAssets, enemyTextures, GraphicsDevice);
                    currentstate = GameState.LEVEL_EDIT;
                }
            }
            else
            {
                overLevelEdit = false;
            }
        }


        private void checkLevelMain(MouseState mouse)
        {
            Rectangle mouseRec = new Rectangle(mouse.X, mouse.Y, 1, 1);
            if (levelMainBox.Intersects(mouseRec))
            {
                overLevelMain = true;
                if (mouse.LeftButton == ButtonState.Pressed && !mouseDown)
                {
                    //do clicked button stuff
                    editorActive = !editorActive;
                    //holdKey = true;
                    //game.initialRun = true;
                   // editor.setUp(game.floor, game.floorBounds, floorAssets, editorAssets, enemyTextures, GraphicsDevice);
                    currentstate = GameState.MAIN_MENU;
                }
            }
            else
            {
                overLevelMain = false;
            }
        }
        private void checkQuit(MouseState mouse)
        {
            Rectangle mouseRec = new Rectangle(mouse.X, mouse.Y, 1, 1);
            if (quitMainBox.Intersects(mouseRec))
            {
                overQuit = true;
                if (mouse.LeftButton == ButtonState.Pressed && !mouseDown)
                {
                    //do clicked button stuff
                    this.Exit();

                }
            }
            else
            {
                overQuit = false;
            }
        }

        private void checkSaveQuit(MouseState mouse)
        {
            Rectangle mouseRec = new Rectangle(mouse.X, mouse.Y, 1, 1);
            if (SaveQuitbox.Intersects(mouseRec))
            {
                overSaveQuit = true;
                if (mouse.LeftButton == ButtonState.Pressed && !mouseDown)
                {
                    //do clicked button stuff
                    //do save game stuff
                    this.Exit();

                }
            }
            else
            {
                overSaveQuit = false;
            }
        }




        private void checkReturntoMenu(MouseState mouse)
        {
            Rectangle mouseRec = new Rectangle(mouse.X, mouse.Y, 1, 1);
            if (returntoMenubox.Intersects(mouseRec))
            {
                overReturntoMenu = true;
                if (mouse.LeftButton == ButtonState.Pressed && !mouseDown)
                {
                    //do clicked button stuff
                    currentstate = GameState.MAIN_MENU;
                    paused = false;
                }
            }
            else
            {
                overReturntoMenu = false;
            }

        }

        private void checkQuitGame(MouseState mouse)
        {
            Rectangle mouseRec = new Rectangle(mouse.X, mouse.Y, 1, 1);
            if (pauseQuitBox.Intersects(mouseRec))
            {
                overPauseQuit = true;
                if (mouse.LeftButton == ButtonState.Pressed && !mouseDown)
                {
                    //do clicked button stuff
                    this.Exit();
                }
            }
            else
            {
                overPauseQuit = false;
            }

        }

        public void DrawMainMenu(SpriteBatch sp, Texture2D tex, Rectangle screen, SpriteFont fnt)
        {
            MouseState mouseMain = Mouse.GetState();
            //draws background menu
            sp.Draw(tex, screen, Color.White);

            //draws title on menu
            sp.DrawString(fnt, "Pachyderm Pummel!", new Vector2(0, 0), Color.OrangeRed);


            Button(startbox, "start", 's');
            Button(leveleditbox, "Level Edit", 'l');
            Button(quitMainBox, "Quit", 'e');

            spriteBatch.Draw(reticle_edit, new Rectangle(mouseMain.X - 20, mouseMain.Y - 20, 40, 40), Color.White);
        }


        public void DrawDeath(SpriteBatch sp, Texture2D tex, Rectangle screen, SpriteFont fnt)
        {
            MouseState mouseDeath = Mouse.GetState();
            //draws background screen
            sp.Draw(tex, screen, Color.White);

            //draws title on menu
            sp.DrawString(bfont, "You are Dead\n\nFinal Score: " + game.GetScore() + "\n\nYou made it\n to level: " + game.GetLevel() + "\n\nYou took: " + game.GetTime(), new Vector2(GraphicsDevice.Viewport.Width/2 + 150, GraphicsDevice.Viewport.Height/2-150), Color.OrangeRed);


            Button(dedMenuBox, "Main Menu", 'd');


            spriteBatch.Draw(reticle_edit, new Rectangle(mouseDeath.X - 20, mouseDeath.Y - 20, 40, 40), Color.White);
        }



        public void DrawPauseMenu()
        {
            // if(!overSaveQuit)
            //Button(SaveQuitbox, "Save and Quit", 'q');
            Button(returntoMenubox, "Main Menu", 'm');
            Button(pauseQuitBox, "Quit Game", 'j');
        }


        public void DrawLevelMain()
        {
            Button(levelMainBox, "Main Menu", 'h');
        }




        public void Button(Rectangle re, string txt, char firstletter)
        {


            spriteBatch.Draw(btn, re, Color.White);
            if (firstletter == 's')
            {
                if (!overStart)
                {
                    spriteBatch.DrawString(bfont, txt, new Vector2(re.X + 25, re.Y + 15), Color.OrangeRed);
                }
                else
                {
                    spriteBatch.DrawString(bfont, txt, new Vector2(re.X + 25, re.Y + 15), Color.Yellow);
                }
            }
            else if (firstletter == 'l')
            {
                if (!overLevelEdit)
                {
                    spriteBatch.DrawString(bfont, txt, new Vector2(re.X + 20, re.Y + 15), Color.OrangeRed);
                }
                else
                {
                    spriteBatch.DrawString(bfont, txt, new Vector2(re.X + 20, re.Y + 15), Color.Yellow);
                }
            }
            else if (firstletter == 'q')
            {
                if (!overSaveQuit)
                {
                    spriteBatch.DrawString(bfont, txt, new Vector2(re.X + 50, re.Y + 15), Color.OrangeRed);
                }
                else
                {
                    spriteBatch.DrawString(bfont, txt, new Vector2(re.X + 50, re.Y + 15), Color.Yellow);
                }
            }
            else if(firstletter == 'm')
            {
                if (!overReturntoMenu)
                {
                    spriteBatch.DrawString(bfont, txt, new Vector2(re.X + 100, re.Y + 15), Color.OrangeRed);
                }                                                        
                else                                                     
                {                                                          
                    spriteBatch.DrawString(bfont, txt, new Vector2(re.X + 100, re.Y + 15), Color.Yellow);
                }
            }
            else if(firstletter == 'd')
            {
                if (!overDedmenu)
                {
                    spriteBatch.DrawString(bfont, txt, new Vector2(re.X + 100, re.Y + 15), Color.OrangeRed);
                }
                else
                {
                    spriteBatch.DrawString(bfont, txt, new Vector2(re.X + 100, re.Y + 15), Color.Yellow);
                }
            }
            else if (firstletter == 'e')
            {
                if (!overQuit)
                {
                    spriteBatch.DrawString(bfont, txt, new Vector2(re.X + 50, re.Y + 15), Color.OrangeRed);
                }
                else
                {
                    spriteBatch.DrawString(bfont, txt, new Vector2(re.X + 50, re.Y + 15), Color.Yellow);
                }
            }
            else if (firstletter == 'j')
            {
                if (!overPauseQuit)
                {
                    spriteBatch.DrawString(bfont, txt, new Vector2(re.X + 100, re.Y + 15), Color.OrangeRed);
                }
                else
                {
                    spriteBatch.DrawString(bfont, txt, new Vector2(re.X + 100, re.Y + 15), Color.Yellow);
                }
            }
            else if (firstletter == 'h')
            {
                if (!overLevelMain)
                {
                    spriteBatch.DrawString(bfont, txt, new Vector2(re.X + 50, re.Y + 15), Color.OrangeRed);
                }
                else
                {
                    spriteBatch.DrawString(bfont, txt, new Vector2(re.X + 50, re.Y + 15), Color.Yellow);
                }
            }


        }


       

       

        
        protected override void Update(GameTime gameTime)
        {
            KeyboardState keyboard = Keyboard.GetState();
            MouseState mouse = Mouse.GetState();

            
            if (keyboard.IsKeyDown(Keys.F11) && prev.IsKeyUp(Keys.F11))
            {
                graphics.IsFullScreen = !graphics.IsFullScreen;
                graphics.ApplyChanges();
            }

            if ((keyboard.IsKeyDown(Keys.Escape) && prev.IsKeyUp(Keys.Escape)) || (keyboard.IsKeyDown(Keys.P) && prev.IsKeyUp(Keys.P)))
            {
                if (currentstate == GameState.GAME)
                {
                    paused = !paused;
                    game.Paused = paused;
                }

            }

            //if game is paused nothing updates except code above this
            if (!paused)
            {
                if (!soundManager.SongPlaying)
                {
                    //oh noes
                    soundManager.playSong("bgm");
                }

                if (currentstate == GameState.GAME)
                {
                    game.UpdateGame(mouse, GraphicsDevice);
                    
                    if (paused)
                    {
                        UpdatePauseMenu();
                    }
                }
                else if (currentstate == GameState.LEVEL_EDIT)
                {
                    editor.UpdateEditor(mouse, GraphicsDevice);
                    UpdateLevelMain();
                }
                else if (currentstate == GameState.MAIN_MENU)
                {
                    //main menu stuff
                    UpdateMainMenu();
                }
                else if(currentstate == GameState.DEATH)
                {
                    //update game death   
                    UpdateDeath();               
                }

                
                if (game.isTransitioning)
                {
                    transTick++;

                    if((transTick >= 4 && isreveresed) || (transTick >= 0 && !isreveresed))
                    {
                        
                        transTick = 0;
                        if(isreveresed == false)
                        {
                            transChange += .1f;
                            if (transChange >= 1.0f)
                            {
                                isreveresed = true;
                            }
                        }
                        else
                        {
                            transChange -= .05f;
                            if (transChange <= 0.0f)
                            {
                                game.isTransitioning = false;
                                transTick = 0;
                                transChange = 0f;
                                isreveresed = false;
                            }
                        }
                    }
                      

                    
                }
                

                if (game.noHealth && currentstate != GameState.DEATH)
                {
                    game.isTransitioning = true;
                    //Thread.Sleep(1000);
                    currentstate = GameState.DEATH;
                    game.noHealth = false;
                }


                base.Update(gameTime);
            }
            else
            {
                UpdatePauseMenu();
            }



            prev = Keyboard.GetState();
            if (mouse.LeftButton == ButtonState.Pressed)
            {
                mouseDown = true;
            }
            else if (mouse.LeftButton == ButtonState.Released)
            {
                mouseDown = false;
            }
        }


        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.Black);
            MouseState mouse = Mouse.GetState();

            //begin drawing
            spriteBatch.Begin();

            switch (currentstate)
            {
                case GameState.MAIN_MENU:
                    
                    DrawMainMenu(spriteBatch, bg, new Rectangle(0, 0, GraphicsDevice.Viewport.Width, GraphicsDevice.Viewport.Height), mfont);
                   
                    break;
                case GameState.GAME:
                    game.DrawGame(GraphicsDevice, spriteBatch);
                   
                    if (paused == true)
                    {
                        spriteBatch.Draw(pz, new Rectangle(300, 50, 1024, 786), Color.White);
                        DrawPauseMenu();
                    }

                    spriteBatch.Draw(reticle, new Rectangle(mouse.X - 20, mouse.Y - 20, 40, 40), Color.White);
                    if (game.isTransitioning)
                    {
                        //draws transition
                        Color mycolor = new Color(Color.Black, transChange);
                        spriteBatch.Draw(trans, new Rectangle(0, 0, GraphicsDevice.Viewport.Width, GraphicsDevice.Viewport.Height), mycolor);
                    }
                    break;
                case GameState.DEATH:
                    //spriteBatch.Draw(ded, new Rectangle(0, 0, GraphicsDevice.Viewport.Width, GraphicsDevice.Viewport.Height), Color.White);
                    //Button(returntoMenubox, "Main Menu", 'm');

                    DrawDeath(spriteBatch, ded, new Rectangle(0, 0, GraphicsDevice.Viewport.Width, GraphicsDevice.Viewport.Height), mfont);
                    if (game.isTransitioning)
                    {
                        //draws transition
                        Color mycolor = new Color(Color.Black, transChange);
                        spriteBatch.Draw(trans, new Rectangle(0, 0, GraphicsDevice.Viewport.Width, GraphicsDevice.Viewport.Height), mycolor);
                    }
                    break;
                case GameState.LEVEL_EDIT:
                    editor.DrawEditor(GraphicsDevice, spriteBatch, font, this);
                    spriteBatch.Draw(reticle_edit, new Rectangle(mouse.X - 20, mouse.Y - 20, 40, 40), Color.White);

                    break;
                default:
                    break;
            }

            spriteBatch.End();

            base.Draw(gameTime);
        }
    }
}
