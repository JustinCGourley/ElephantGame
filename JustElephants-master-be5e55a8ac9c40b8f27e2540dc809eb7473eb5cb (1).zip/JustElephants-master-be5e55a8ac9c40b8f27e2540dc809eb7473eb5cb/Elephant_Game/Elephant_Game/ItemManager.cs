﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Elephant_Game
{
    class ItemManager
    {
        Random ran = new Random();

        public Item getItem(Vector2 pos)
        {
            Rectangle rec = new Rectangle((int)pos.X, (int)pos.Y, 50, 50);
            Item item = null;
            int chance = ran.Next(1000) + 1;

            //if random number 1 - 1000 is above 750, spawn an item
            if (chance >= 800)
            {
                //generate a new random number 1 - 10
                chance = ran.Next(10) + 1;
                //1-5 spawns a peanut
                if (chance >= 1 && chance <= 5)
                {
                    item = new Peanut_Pickup(rec);
                }
                //6 - 7 spawns a level-up
                if (chance >= 6 && chance <= 7)
                {
                    item = new LevelUp_Pickup(rec);
                }
                //8 - 10 spawns an invincibility pick-up
                if (chance >= 8 && chance <= 10)
                {
                    item = new Invincible_Pickup(rec);
                }
            }



            


            return item;
        }
    }
}
