﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Elephant_Game
{
    class Collisions
    {

        public bool checkMove(int floorType)
        {
            int[] stopMove = { 0, 1, 2, 3, 5, 29, 31 };
            bool allow = false;

            foreach (var item in stopMove)
            {
                if (item == floorType)
                {
                    allow = true;
                }
            }


            return allow;
        }

    }
}