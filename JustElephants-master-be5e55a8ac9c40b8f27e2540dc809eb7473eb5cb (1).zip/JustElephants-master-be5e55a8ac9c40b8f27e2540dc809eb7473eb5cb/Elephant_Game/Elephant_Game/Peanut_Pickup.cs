﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Elephant_Game
{
    class Peanut_Pickup : Item
    {

        public Peanut_Pickup(Rectangle pos) : base (pos, 0)
        {
        }

        public override void function(Player player)
        {
            if (player.CurrentHealth == player.HealthSlots)
            {
                return;
            }
            else
            {
                player.CurrentHealth++;
                if (player.CurrentHealth > player.HealthSlots)
                {
                    player.CurrentHealth = player.HealthSlots;
                    return;
                }
                PickedUp = true;
            }
        }
    }
}
