﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System.IO;
using Newtonsoft.Json;

namespace Elephant_Game
{
    class RoomGenerator
    {

        List<int[,]> floors = new List<int[,]>();
        public int[,] floor { get; set; }
        List<int[,]> floorsGiven = new List<int[,]>();
        Random ran = new Random();
        Enemy[] enemyToReturn;
        List<Enemy[]> enemiesList = new List<Enemy[]>();
        GraphicsDevice graphics;
        int lastBoss = -1;
        int[,] defaultFloor = {
                         {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                         {0, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 0},
                         {0, 17, 4, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 4, 17, 0},
                         {0, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 0},
                         {0, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 0},
                         {0, 17, 17, 17, 17, 17, 17, 17, 17, 17, 4, 17, 17, 17, 17, 17, 17, 17, 17, 17, 0},
                         {0, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 0},
                         {0, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 0},
                         {0, 17, 4, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 4, 17, 0},
                         {0, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 0},
                         {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
                    };

        public int[,] DefaultFloor { get { return defaultFloor; } }


        public void LoadRooms(GraphicsDevice graphics)
        {
            this.graphics = graphics;
            try
            {
                StreamReader reader = new StreamReader("Floors.json");
                string data = reader.ReadToEnd();
                reader.Close();
                List<int[,]> floorGet = JsonConvert.DeserializeObject<List<int[,]>>(data);
                floors = floorGet;
            } catch (Exception ex)
            {
                Console.WriteLine("Unable to read file/error reading file:\n"+ex);


                floors.Add(defaultFloor);
            }

            try
            {
                StreamReader reader = new StreamReader("EnemySpawn.json");
                string data = reader.ReadToEnd();
                reader.Close();
                List<Enemy[]> enemyGet = JsonConvert.DeserializeObject<List<Enemy[]>>(data);

                for (int i = 0; i < enemyGet.Count; i++)
                {
                    foreach (var item in enemyGet[i])
                    {
                        item.Pos.X = (int)((item.Pos.X - 250) * 1.48);
                        item.Pos.Y = (int)((item.Pos.Y - 175) * 1.7);
                    }
                }

                enemiesList = enemyGet;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Unable to read file/error reading file:\n" + ex);


                floors.Add(defaultFloor);
            }
        }

        public int[,] GetBossRoom()
        {
            return defaultFloor;
        }

        public Enemy[] GetBossEnemy(List<Rectangle> floorBounds)
        {
            int bossCount = 5;
            int bossPick = -1;
            do
            {
                bossPick = ran.Next(bossCount);
            } while (lastBoss == bossPick);
            lastBoss = bossPick;

            Enemy bossEnemy = null;
            switch (bossPick)
            {
                case 0: //add in the bull boss
                    BullBoss bullboss = new BullBoss(floorBounds);

                    bullboss.StartHealth = 100;
                    bullboss.Health = bullboss.StartHealth;
                    bullboss.Damage = 1;
                    bullboss.Speed = 15;
                    bullboss.Pos = new Vector2((graphics.Viewport.Width / 2), (graphics.Viewport.Height / 2));
                    bossEnemy = bullboss;
                    break;

                case 1: //add in the bounce boss
                    BounceBoss bounceboss = new BounceBoss(floorBounds);

                    bounceboss.StartHealth = 200;
                    bounceboss.Health = bounceboss.StartHealth;
                    bounceboss.Damage = 1;
                    bounceboss.Speed = 8;
                    bounceboss.Pos = new Vector2((graphics.Viewport.Width / 2), (graphics.Viewport.Height / 2));
                    bossEnemy = bounceboss;
                    break;

                case 2: //add in the double bull boss
                    SpeedBoss speedBoss = new SpeedBoss(floorBounds);

                    speedBoss.StartHealth = 75;
                    speedBoss.Health = speedBoss.StartHealth;
                    speedBoss.Damage = 1;
                    speedBoss.Speed = 20;
                    speedBoss.Pos = new Vector2((graphics.Viewport.Width / 2), (graphics.Viewport.Height / 2));
                    bossEnemy = speedBoss;
                    break;
                    
                case 3: //add in the double bull boss
                    SlowShootBoss shootBoss = new SlowShootBoss();

                    shootBoss.StartHealth = 100;
                    shootBoss.Health = shootBoss.StartHealth;
                    shootBoss.Damage = 1;
                    shootBoss.Speed = 5;
                    shootBoss.Pos = new Vector2((graphics.Viewport.Width / 2), (graphics.Viewport.Height / 2));
                    bossEnemy = shootBoss;
                    break;

                case 4: //add in the double bull boss
                    ShootBoss multiShootBoss = new ShootBoss();

                    multiShootBoss.StartHealth = 200;
                    multiShootBoss.Health = multiShootBoss.StartHealth;
                    multiShootBoss.Damage = 1;
                    multiShootBoss.Speed = 0;
                    multiShootBoss.Pos = new Vector2((graphics.Viewport.Width / 2), (graphics.Viewport.Height / 2));
                    bossEnemy = multiShootBoss;
                    break;

                default: //(somehow an invalid boss number was generated, default add the bull boss)
                    BullBoss defaultBoss = new BullBoss(floorBounds);

                    defaultBoss.StartHealth = 100;
                    defaultBoss.Health = defaultBoss.StartHealth;
                    defaultBoss.Damage = 1;
                    defaultBoss.Speed = 15;
                    defaultBoss.Pos = new Vector2((graphics.Viewport.Width / 2), (graphics.Viewport.Height / 2));
                    bossEnemy = defaultBoss;
                break;
            }

            Enemy[] list = new Enemy[1];
            list[0] = bossEnemy;
        
            return list;
        }

        public int[,] GetRoom()
        {
            int[,] randomFloor = defaultFloor;
            Enemy[] enemyForFloor = new Enemy[0];
            //TODO get random floor data
            try
            {
                bool newFloor = false;
                int repeatCount = 0;
                do
                {
                    int randomNum = ran.Next(floors.Count);
                    newFloor = true;
                    randomFloor = floors[randomNum];
                    enemyForFloor = enemiesList[randomNum];
                    foreach (var item in floorsGiven)
                    {
                        if (randomFloor == item)
                        {
                            newFloor = false;
                        }
                    }
                    repeatCount++;
                } while (!newFloor && repeatCount < 10000);
                if (randomFloor == null || repeatCount >= 10000)
                {
                    randomFloor = defaultFloor;
                }
                Console.WriteLine("Generated Room - Repeat Count: {0}",repeatCount);
                floorsGiven.Add(randomFloor);
                
                
            }
            catch(Exception ex)
            {
                Console.WriteLine("Unable to load data.. defaulting floor.");
                randomFloor = defaultFloor;

            }

            enemyToReturn = enemyForFloor;
            return randomFloor;
        }

        public Enemy[] GetEnemyForFloor()
        {
            Enemy[] returnEnemy = enemyToReturn;
            enemyToReturn = null;

            return returnEnemy;
        }

    }
}
