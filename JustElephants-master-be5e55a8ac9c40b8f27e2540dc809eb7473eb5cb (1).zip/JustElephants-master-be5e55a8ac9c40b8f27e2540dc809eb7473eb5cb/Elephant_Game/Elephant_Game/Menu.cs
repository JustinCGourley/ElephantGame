﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
namespace Elephant_Game
{
    class Menu
    {
        bool overStart = false;
        Rectangle startbox;

        GameState gameState;


        public GameState returnState()
        {
            return gameState;
        }

        private void checkStart(MouseState mouse)
        {
            Rectangle mouseRec = new Rectangle(mouse.X, mouse.Y, 1, 1);
            if (startbox.Intersects(mouseRec))
            {
                overStart = true;
                if (mouse.LeftButton == ButtonState.Pressed)
                {
                    //do clicked button stuff
                }
            }
            else
            {
                overStart = false;
            }
        }

        public void UpdateMainMenu()
        {
            MouseState mouse = Mouse.GetState();

            checkStart(mouse);
        }



        public void DrawMainMenu(SpriteBatch sp, Texture2D tex, Rectangle screen, SpriteFont fnt)
        {
            //draws background menu
            sp.Draw(tex, screen, Color.White);

            //draws title on menu
            sp.DrawString(fnt, "Pachyderm Pummel!", new Vector2(0, 0), Color.OrangeRed);
        }



        public void UpdatePauseMenu()
        {

        }



        public void DrawPauseMenu()
        {

        }








    }
}
