﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace ElephantGame
{
    class Bullet
    {
        public int Lifespan { get; set; }
        public double Damage { get; set; }
        public Vector2 Direction { get; set; }
        public Texture2D BulletPic { get; set; }
        public float Rotation { get; set; }
        public Vector2 Loc { get; set; }
        public Vector2 Origin { get; set; }

        public Bullet ()
        {
            Origin = new Vector2(33/2, 15/2);
        }
        
        public void UpdateBullet()
        {
            Vector2 newPos = new Vector2();
            newPos = Loc;
            if (Lifespan <= 20)
            {
                newPos.X += Direction.X/2;
                newPos.Y += Direction.Y/2;
            }
            else
            {
                newPos.X += Direction.X;
                newPos.Y += Direction.Y;
            }
            Loc = newPos;
        }

        public bool CheckLife(int[,] floors, int maxWidth, int maxHeight, int tileWidth, int tileHeight)
        {
            Lifespan--;


            int playerWidth = (int)Loc.X / (maxWidth / tileWidth);
            int playerHeight = (int)Loc.Y / (maxHeight / tileHeight);

            if (Lifespan <= 0)
            {
                return false;
            }
            //check tile you are on
            if (floors[playerHeight, playerWidth] == 3 || floors[playerHeight, playerWidth] == 0)
            {
                return false;
            }
            else
            {
                return true;
            }
        }
    }
}
