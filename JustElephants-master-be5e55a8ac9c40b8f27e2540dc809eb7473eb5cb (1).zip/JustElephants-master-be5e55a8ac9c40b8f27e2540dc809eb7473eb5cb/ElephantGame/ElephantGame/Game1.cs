﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace ElephantGame
{
    /// <summary>
    /// This is the main type for your game.
    /// </summary>
    public class Game1 : Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;
        RoomGenerator roomGen = new RoomGenerator();

        //---global var's---
        float WORLD_WIDTH, WORLD_HEIGHT;
        bool holdKey = false;
        const int FLOOR_WIDTH = 17, FLOOR_HEIGHT = 9;
        //player vars
        Player player;
        List<Bullet> playerBullets;
        //floor vars
        int[,] floor = new int[FLOOR_HEIGHT, FLOOR_WIDTH];
        Rectangle[,] floorBounds = new Rectangle[FLOOR_HEIGHT, FLOOR_WIDTH];


        //---assets---
        //player assets
        Texture2D playerImage_Still;
        Texture2D playerShot;
        //enemy assets
        Texture2D smallMouse_Still;
        //floor assets
        Texture2D[] floorAssets = new Texture2D[5];
        


        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            graphics.PreferredBackBufferHeight = 900;
            graphics.PreferredBackBufferWidth = 1600;
        }

        protected override void Initialize()
        {
            //show mouse
            this.IsMouseVisible = true;

            //setup initial variables
            WORLD_WIDTH = GraphicsDevice.Viewport.Width;
            WORLD_HEIGHT = GraphicsDevice.Viewport.Height;

            playerBullets = new List<Bullet>();

            roomGen.LoadRooms();
            floor = roomGen.GetRoom();


            System.Console.WriteLine("Finished Initializing");
            base.Initialize();
        }

        protected override void LoadContent()
        {
            spriteBatch = new SpriteBatch(GraphicsDevice);
            
            //asset loading
            //player content load
            playerImage_Still = Content.Load<Texture2D>("Sprites/EnemieselephantSprite");
            playerShot = Content.Load<Texture2D>("Sprites/Player/water projectile");
            //enemy content load
            smallMouse_Still = Content.Load<Texture2D>("d_mouse");

            //load floor assets
            floorAssets[0] = Content.Load<Texture2D>("Tiles/groundtilewithrockwall");
            floorAssets[1] = Content.Load<Texture2D>("Tiles/groundtilewithsandedge");
            floorAssets[2] = Content.Load<Texture2D>("Tiles/groundtilewithrock");
            floorAssets[3] = Content.Load<Texture2D>("Tiles/groundtilewithsmallrocks");
            floorAssets[4] = Content.Load<Texture2D>("Tiles/groundtilewithpuddle");

            //load player
            loadPlayer();

            System.Console.WriteLine("Finished Loading Content");
        }
        
        protected override void UnloadContent()
        {
        }
        
        protected override void Update(GameTime gameTime)
        {
            KeyboardState keyboard = Keyboard.GetState();
            MouseState mouse = Mouse.GetState();

            if (keyboard.IsKeyDown(Keys.F11) && holdKey == false)
            {
                graphics.IsFullScreen = !(graphics.IsFullScreen);
                graphics.ApplyChanges();
                WORLD_WIDTH = GraphicsDevice.Viewport.Width;
                WORLD_HEIGHT = GraphicsDevice.Viewport.Height;
                holdKey = true;
            }
            if (keyboard.IsKeyDown(Keys.Escape))
            {
                this.Exit();
            }
            if (keyboard.IsKeyUp(Keys.F11))
            {
                holdKey = false;
            }


            //player shoot
            if (mouse.LeftButton == ButtonState.Pressed)
            {
                Bullet shot = player.Shoot();
                if (shot != null)
                { 
                    playerBullets.Add(shot);
                }
            }

            //update player movement
            player.CheckAllowMove(floorBounds, floor, GraphicsDevice.Viewport.Width, GraphicsDevice.Viewport.Height, FLOOR_WIDTH, FLOOR_HEIGHT);
            player.Update();

            //update player bullets
            List<Bullet> playerBulletsToRemove = new List<Bullet>();
            foreach (var item in playerBullets)
            {
                item.UpdateBullet();
                bool alive = item.CheckLife(floor, GraphicsDevice.Viewport.Width, GraphicsDevice.Viewport.Height, FLOOR_WIDTH, FLOOR_HEIGHT);
                if (!alive)
                {
                    playerBulletsToRemove.Add(item);
                }
            }
            //remove any dead bullets
            foreach (var item in playerBulletsToRemove)
            {
                playerBullets.Remove(item);
            }
            
            base.Update(gameTime);
        }
        
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.Black);

            //begin drawing
            spriteBatch.Begin();

            //draw floor tiles
            int height = 0;
            int width = 0;
            Rectangle floorRec = new Rectangle(0, 0, GraphicsDevice.Viewport.Width / FLOOR_WIDTH, GraphicsDevice.Viewport.Height / FLOOR_HEIGHT);
            foreach (var item in floor)
            {
                floorRec.X = (GraphicsDevice.Viewport.Width / FLOOR_WIDTH) * width;
                floorRec.Y = (GraphicsDevice.Viewport.Height / FLOOR_HEIGHT) * height;
                floorBounds[height, width] = floorRec;
                spriteBatch.Draw(floorAssets[floor[height, width]], floorRec, Color.White);

                width++;
                if (width == FLOOR_WIDTH)
                {
                    width = 0;
                    height++;
                }
            }

            //draw all bullets
            foreach (var item in playerBullets)
            {
                //draw bullet
                spriteBatch.Draw(playerShot, item.Loc, null, Color.White, item.Rotation, item.Origin, 1.0f, SpriteEffects.None, 1);
            }

            //draw player
            spriteBatch.Draw(playerImage_Still, player.Pos, null, Color.White, player.rotation, player.Origin, 1.0f, SpriteEffects.None, 1);
            // -.- justin you can use a rectangle use "destinationRectangle: [rectangle]" and "rotation: [rotation]" ffs
            
            spriteBatch.End();

            base.Draw(gameTime);
        }

        public void loadPlayer()
        {
            System.Console.WriteLine("Loading Player");
            int xPos = (GraphicsDevice.Viewport.Width/2) - playerImage_Still.Width/2;
            int yPos = (GraphicsDevice.Viewport.Height/2) - playerImage_Still.Height/2;
            System.Console.WriteLine("Set-Up default X,Y");
            //setup default player attributes
            player = new Player(xPos, yPos)
            {
                Health = 5,
                Damage = 2,
                Range = 60,
                Speed = 5,
                ShotSpeed = 20,
                BulletSpeed = 10,
                playerImage = playerImage_Still
            };
            System.Console.WriteLine("Created Player");
            //TODO: Attempt to load saved playdata from existing game (if there is one)
        }
    }
}
