﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace ElephantGame
{
    /// <summary>
    /// Player Class
    /// </summary>
    /// Tracks health, speed, shotspeed, range, and damage
    class Player
    {
        //player position
        public Vector2 Pos;
        public Vector2 Origin;
        public float rotation;
        //collision checks
        bool[] allowMove = new bool[4];

        //player stats
        public int Health { get; set; }
        public int Speed { get; set; }
        public int ShotSpeed { get; set; }
        public int BulletSpeed { get; set; }
        public int Range { get; set; }
        public double Damage { get; set; }
        public int WaterLevel { get; set; }

        //player image
        public Texture2D playerImage { get; set; }
         
        private int shotTick = 0;
        

        public Player()
        {
            //set-up player Position
            Pos = new Vector2(0f, 0f);
            //set-up origin point
            Origin = new Vector2(playerImage.Bounds.X/2, playerImage.Bounds.Y/2);
        }

        public Player(float x, float y)
        {
            Pos = new Vector2(x, y);
            //set-up origin point
            Origin = new Vector2(62 / 2, 81 / 2);
        }

        public void Update()
        {
            MovePlayer();
            UpdateRotation();
            UpdateTick();
        }

        public void MovePlayer()
        {
            //allow movement for player
            KeyboardState key = Keyboard.GetState();

            //0 = up, 1 = left, 2 = down, 3 = right

            if (key.IsKeyDown(Keys.W))
            {
                if (allowMove[0])
                {
                    Pos.Y -= Speed;
                }
            }
            if (key.IsKeyDown(Keys.A))
            {
                if (allowMove[1])
                {
                    Pos.X -= Speed;
                }
            }
            if (key.IsKeyDown(Keys.S))
            {
                if (allowMove[2])
                {
                    Pos.Y += Speed;
                }
            }
            if (key.IsKeyDown(Keys.D))
            {
                if (allowMove[3])
                {
                    Pos.X += Speed;
                }
            }
        }

        public void UpdateRotation()
        {
            try
            {
                MouseState mouse = Mouse.GetState();
                Vector2 mouseVec = new Vector2(mouse.X, mouse.Y);
                Vector2 playerPos = new Vector2(Pos.X, Pos.Y);
                Vector2 direction = mouseVec - playerPos;
                float angle = (float)Math.Atan2(-direction.Y, -direction.X);

                angle += (float)(Math.PI * 0.5f);
                rotation = angle;
            } catch (Exception ex)
            {
                Console.WriteLine("!-Rotation Update Error occured-!");
            }
        }

        private void UpdateTick()
        {
            if (shotTick != 0)
            {
                shotTick--;
            }
        }

        public Bullet Shoot()
        {
            Bullet shot = null;

            if (shotTick == 0)
            {
                double X = -(Math.Sin(rotation));
                double Y = Math.Cos(rotation);
                Vector2 direction = new Vector2((float)(X * BulletSpeed), (float)(Y * BulletSpeed));
                shot = new Bullet()
                {
                    Lifespan = Range,
                    Damage = this.Damage,
                    Direction = direction,
                    Loc = Pos,
                    Rotation = (float)(rotation - (Math.PI * 1.5))
                };

                shotTick = ShotSpeed;
            }

            return shot;
        }

        public void CheckAllowMove(Rectangle[,] floorRec, int[,] floors, int maxWidth, int maxHeight, int tileWidth, int tileHeight)
        {
            allowMove[0] = true;
            allowMove[1] = true;
            allowMove[2] = true;
            allowMove[3] = true;
            

            int playerWidth = (int)Pos.X / (maxWidth / tileWidth);
            int playerHeight = (int)Pos.Y / (maxHeight / tileHeight);

            //check tile you are on
            if (floors[playerHeight, playerWidth] == 3 || floors[playerHeight, playerWidth] == 0)
            {
                //get middle for X and Y of current tile
                int xMid = floorRec[playerHeight, playerWidth].X + (floorRec[playerHeight, playerWidth].Width / 2);
                int yMid = floorRec[playerHeight, playerWidth].Y + (floorRec[playerHeight, playerWidth].Height / 2);
                //stop movement
                allowMove[0] = false;
                allowMove[1] = false;
                allowMove[2] = false;
                allowMove[3] = false;

                //X Push
                if (Pos.X > xMid)
                {
                    Pos.X++;
                }
                else
                {
                    Pos.X--;
                }
                //Y Push
                if (Pos.Y > yMid)
                {
                    Pos.Y++;
                }
                else
                {
                    Pos.Y--;
                }
            }

            //check floor above you (currently checks for rocks[3] and walls[0]
            try
            {
                if (floors[playerHeight - 1, playerWidth] == 3 || floors[playerHeight - 1, playerWidth] == 0)//check for rocks and walls
                {
                    if (Pos.Y - (playerImage.Width*0.85) <= floorRec[playerHeight - 1, playerWidth].Y + floorRec[playerHeight - 1, playerWidth].Height)
                    {
                        allowMove[0] = false;
                        if ((Pos.Y - (playerImage.Width * 0.85)) + 1 < floorRec[playerHeight - 1, playerWidth].Y + floorRec[playerHeight - 1, playerWidth].Height)
                        {
                            Pos.Y++;
                        }

                    }
                }
            } catch (Exception ex)
            {
                Console.WriteLine("Exception occured when attempting to detect collision with floor tiles above\nException: " + ex);
            }

            //checks floor below you
            try
            {
                if (floors[playerHeight + 1, playerWidth] == 3 || floors[playerHeight + 1, playerWidth] == 0)
                {
                    if (Pos.Y + playerImage.Width >= floorRec[playerHeight + 1, playerWidth].Y)
                    {
                        allowMove[2] = false;
                        if (Pos.Y + playerImage.Width > floorRec[playerHeight + 1, playerWidth].Y)
                        {
                            Pos.Y--;
                        }
                    }
                }
            }catch (Exception ex)
            {
                Console.WriteLine("Exception occured when attempting to detect collision with floor tiles below\nException: " + ex);
            }

            //checks floor to the left of you
            try
            {
                if (floors[playerHeight, playerWidth - 1] == 3 || floors[playerHeight, playerWidth - 1] == 0)
                {
                    if (Pos.X - playerImage.Width <= floorRec[playerHeight, playerWidth - 1].X + floorRec[playerHeight, playerWidth - 1].Width)
                    {
                        allowMove[1] = false;
                        if (Pos.X - playerImage.Width < floorRec[playerHeight, playerWidth - 1].X + floorRec[playerHeight, playerWidth - 1].Width)
                        {
                            Pos.X++;
                        }
                    }
                }
            } catch (Exception ex)
            {
                Console.WriteLine("Exception occured when attempting to detect collision with floor tiles to the left\nException: " + ex);
            }

            //checks floor to the right of you
            try
            {
                if (floors[playerHeight, playerWidth + 1] == 3 || floors[playerHeight, playerWidth + 1] == 0)
                {
                    if (Pos.X + playerImage.Width >= floorRec[playerHeight, playerWidth + 1].X)
                    {
                        allowMove[3] = false;
                        if (Pos.X + playerImage.Width > floorRec[playerHeight, playerWidth + 1].X)
                        {
                            Pos.X--;
                        }
                    }
                }
            } catch (Exception ex)
            {
                Console.WriteLine("Exception occured when attempting to detect collision with floor tiles to the left\nException: " + ex);
            }
        }

        

    }
}
